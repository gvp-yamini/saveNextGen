function addWidgetsfrmDashboard() {
    frmDashboard.setDefaultUnit(kony.flex.DP);
    var flxMenuMain = new kony.ui.FlexContainer({
        "autogrowMode": kony.flex.AUTOGROW_NONE,
        "clipBounds": true,
        "height": "92%",
        "id": "flxMenuMain",
        "isVisible": true,
        "layoutType": kony.flex.FLOW_VERTICAL,
        "right": "100%",
        "skin": "slFbox",
        "top": "8%",
        "width": "65%",
        "zIndex": 1
    }, {}, {});
    flxMenuMain.setDefaultUnit(kony.flex.DP);
    var flxLine = new kony.ui.FlexContainer({
        "autogrowMode": kony.flex.AUTOGROW_NONE,
        "centerX": "50%",
        "clipBounds": true,
        "height": "1px",
        "id": "flxLine",
        "isVisible": true,
        "layoutType": kony.flex.FREE_FORM,
        "left": "80dp",
        "skin": "sknline",
        "top": "0dp",
        "width": "100%",
        "zIndex": 1
    }, {}, {});
    flxLine.setDefaultUnit(kony.flex.DP);
    flxLine.add();
    var flxDashboard = new kony.ui.FlexContainer({
        "autogrowMode": kony.flex.AUTOGROW_NONE,
        "clipBounds": true,
        "height": "10%",
        "id": "flxDashboard",
        "isVisible": true,
        "layoutType": kony.flex.FREE_FORM,
        "left": "0dp",
        "onTouchEnd": AS_FlexContainer_adc0d8295ff646dd88a6c936ddf57e1b,
        "skin": "slFbox",
        "top": 0,
        "width": "100%"
    }, {}, {});
    flxDashboard.setDefaultUnit(kony.flex.DP);
    var Label04125fb89a62f40 = new kony.ui.Label({
        "centerY": "50%",
        "id": "Label04125fb89a62f40",
        "isVisible": true,
        "left": "10%",
        "skin": "LBLMOBCB28FFFFFF",
        "text": "Dashboard",
        "textStyle": {
            "letterSpacing": 0,
            "strikeThrough": false
        },
        "width": kony.flex.USE_PREFFERED_SIZE
    }, {
        "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
        "padding": [0, 0, 0, 0],
        "paddingInPixel": false
    }, {
        "textCopyable": false
    });
    var CopyflxLine0fd5bfc8da0be47 = new kony.ui.FlexContainer({
        "autogrowMode": kony.flex.AUTOGROW_NONE,
        "bottom": "0dp",
        "centerX": "50%",
        "clipBounds": true,
        "height": "1px",
        "id": "CopyflxLine0fd5bfc8da0be47",
        "isVisible": true,
        "layoutType": kony.flex.FREE_FORM,
        "skin": "sknline",
        "width": "90%",
        "zIndex": 1
    }, {}, {});
    CopyflxLine0fd5bfc8da0be47.setDefaultUnit(kony.flex.DP);
    CopyflxLine0fd5bfc8da0be47.add();
    flxDashboard.add(
    Label04125fb89a62f40, CopyflxLine0fd5bfc8da0be47);
    var flxTrips = new kony.ui.FlexContainer({
        "autogrowMode": kony.flex.AUTOGROW_NONE,
        "clipBounds": true,
        "height": "10%",
        "id": "flxTrips",
        "isVisible": true,
        "layoutType": kony.flex.FREE_FORM,
        "left": "0dp",
        "onTouchEnd": AS_FlexContainer_0c10620f49184e2d9286765f14c654aa,
        "skin": "slFbox",
        "top": "0dp",
        "width": "100%"
    }, {}, {});
    flxTrips.setDefaultUnit(kony.flex.DP);
    var CopyLabel0281cc3aac14d49 = new kony.ui.Label({
        "centerY": "50%",
        "id": "CopyLabel0281cc3aac14d49",
        "isVisible": true,
        "left": "10%",
        "skin": "LBLMOBCB28FFFFFF",
        "text": "Trips",
        "textStyle": {
            "letterSpacing": 0,
            "strikeThrough": false
        },
        "width": kony.flex.USE_PREFFERED_SIZE
    }, {
        "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
        "padding": [0, 0, 0, 0],
        "paddingInPixel": false
    }, {
        "textCopyable": false
    });
    var CopyflxLine0932af4004df445 = new kony.ui.FlexContainer({
        "autogrowMode": kony.flex.AUTOGROW_NONE,
        "bottom": "0px",
        "centerX": "50%",
        "clipBounds": true,
        "height": "1px",
        "id": "CopyflxLine0932af4004df445",
        "isVisible": true,
        "layoutType": kony.flex.FREE_FORM,
        "skin": "sknline",
        "width": "90%",
        "zIndex": 1
    }, {}, {});
    CopyflxLine0932af4004df445.setDefaultUnit(kony.flex.DP);
    CopyflxLine0932af4004df445.add();
    flxTrips.add(
    CopyLabel0281cc3aac14d49, CopyflxLine0932af4004df445);
    var flxIssues = new kony.ui.FlexContainer({
        "autogrowMode": kony.flex.AUTOGROW_NONE,
        "clipBounds": true,
        "height": "10%",
        "id": "flxIssues",
        "isVisible": true,
        "layoutType": kony.flex.FREE_FORM,
        "left": "0dp",
        "onTouchEnd": AS_FlexContainer_f12ce7f111f747b69c41800b31725b99,
        "skin": "slFbox",
        "top": "0dp",
        "width": "100%"
    }, {}, {});
    flxIssues.setDefaultUnit(kony.flex.DP);
    var CopyLabel0202755656a1046 = new kony.ui.Label({
        "centerY": "50%",
        "id": "CopyLabel0202755656a1046",
        "isVisible": true,
        "left": "10%",
        "skin": "LBLMOBCB28FFFFFF",
        "text": "Issues",
        "textStyle": {
            "letterSpacing": 0,
            "strikeThrough": false
        },
        "width": kony.flex.USE_PREFFERED_SIZE
    }, {
        "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
        "padding": [0, 0, 0, 0],
        "paddingInPixel": false
    }, {
        "textCopyable": false
    });
    var CopyflxLine0b414cfb2ffdf49 = new kony.ui.FlexContainer({
        "autogrowMode": kony.flex.AUTOGROW_NONE,
        "bottom": "0dp",
        "centerX": "50%",
        "clipBounds": true,
        "height": "1px",
        "id": "CopyflxLine0b414cfb2ffdf49",
        "isVisible": true,
        "layoutType": kony.flex.FREE_FORM,
        "skin": "sknline",
        "width": "90%",
        "zIndex": 1
    }, {}, {});
    CopyflxLine0b414cfb2ffdf49.setDefaultUnit(kony.flex.DP);
    CopyflxLine0b414cfb2ffdf49.add();
    flxIssues.add(
    CopyLabel0202755656a1046, CopyflxLine0b414cfb2ffdf49);
    var flxContractors = new kony.ui.FlexContainer({
        "autogrowMode": kony.flex.AUTOGROW_NONE,
        "clipBounds": true,
        "height": "10%",
        "id": "flxContractors",
        "isVisible": true,
        "layoutType": kony.flex.FREE_FORM,
        "left": "0dp",
        "onTouchEnd": AS_FlexContainer_fed67b330718437db918eecc9fe960a7,
        "skin": "slFbox",
        "top": "0dp",
        "width": "100%"
    }, {}, {});
    flxContractors.setDefaultUnit(kony.flex.DP);
    var CopyLabel03d0b0b7981944a = new kony.ui.Label({
        "centerY": "50%",
        "id": "CopyLabel03d0b0b7981944a",
        "isVisible": true,
        "left": "10%",
        "skin": "LBLMOBCB28FFFFFF",
        "text": "Contractors",
        "textStyle": {
            "letterSpacing": 0,
            "strikeThrough": false
        },
        "width": kony.flex.USE_PREFFERED_SIZE
    }, {
        "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
        "padding": [0, 0, 0, 0],
        "paddingInPixel": false
    }, {
        "textCopyable": false
    });
    var CopyflxLine01e956f0002f44e = new kony.ui.FlexContainer({
        "autogrowMode": kony.flex.AUTOGROW_NONE,
        "bottom": "0dp",
        "centerX": "50%",
        "clipBounds": true,
        "height": "1px",
        "id": "CopyflxLine01e956f0002f44e",
        "isVisible": true,
        "layoutType": kony.flex.FREE_FORM,
        "skin": "sknline",
        "width": "90%",
        "zIndex": 1
    }, {}, {});
    CopyflxLine01e956f0002f44e.setDefaultUnit(kony.flex.DP);
    CopyflxLine01e956f0002f44e.add();
    flxContractors.add(
    CopyLabel03d0b0b7981944a, CopyflxLine01e956f0002f44e);
    var flxLogout = new kony.ui.FlexContainer({
        "autogrowMode": kony.flex.AUTOGROW_NONE,
        "clipBounds": true,
        "height": "10%",
        "id": "flxLogout",
        "isVisible": true,
        "layoutType": kony.flex.FREE_FORM,
        "left": "0dp",
        "onTouchEnd": AS_FlexContainer_3b286f168fdc47cf9879d483cf9b4748,
        "skin": "slFbox",
        "top": "0dp",
        "width": "100%"
    }, {}, {});
    flxLogout.setDefaultUnit(kony.flex.DP);
    var CopyLabel0d0d31936215146 = new kony.ui.Label({
        "centerY": "50%",
        "id": "CopyLabel0d0d31936215146",
        "isVisible": true,
        "left": "10%",
        "skin": "LBLMOBCB28FFFFFF",
        "text": "Logout",
        "textStyle": {
            "letterSpacing": 0,
            "strikeThrough": false
        },
        "width": kony.flex.USE_PREFFERED_SIZE
    }, {
        "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
        "padding": [0, 0, 0, 0],
        "paddingInPixel": false
    }, {
        "textCopyable": false
    });
    var CopyflxLine0c6f4c764071841 = new kony.ui.FlexContainer({
        "autogrowMode": kony.flex.AUTOGROW_NONE,
        "bottom": "0dp",
        "centerX": "50%",
        "clipBounds": true,
        "height": "1px",
        "id": "CopyflxLine0c6f4c764071841",
        "isVisible": true,
        "layoutType": kony.flex.FREE_FORM,
        "skin": "sknline",
        "width": "100%",
        "zIndex": 1
    }, {}, {});
    CopyflxLine0c6f4c764071841.setDefaultUnit(kony.flex.DP);
    CopyflxLine0c6f4c764071841.add();
    flxLogout.add(
    CopyLabel0d0d31936215146, CopyflxLine0c6f4c764071841);
    flxMenuMain.add(
    flxLine, flxDashboard, flxTrips, flxIssues, flxContractors, flxLogout);
    var flxOuter = new kony.ui.FlexContainer({
        "autogrowMode": kony.flex.AUTOGROW_NONE,
        "clipBounds": true,
        "height": "100%",
        "id": "flxOuter",
        "isVisible": true,
        "layoutType": kony.flex.FREE_FORM,
        "left": "0dp",
        "skin": "slFbox",
        "top": "0dp",
        "width": "100%",
        "zIndex": 1
    }, {}, {});
    flxOuter.setDefaultUnit(kony.flex.DP);
    var FlexContainer0af4ba12e07cb44 = new kony.ui.FlexContainer({
        "autogrowMode": kony.flex.AUTOGROW_NONE,
        "clipBounds": true,
        "height": "8%",
        "id": "FlexContainer0af4ba12e07cb44",
        "isVisible": true,
        "layoutType": kony.flex.FREE_FORM,
        "left": "0",
        "skin": "CopyflxBGGreen08723e3e9fec344",
        "top": "0",
        "width": "100%"
    }, {}, {});
    FlexContainer0af4ba12e07cb44.setDefaultUnit(kony.flex.DP);
    var lblTitle = new kony.ui.Label({
        "centerX": "48%",
        "centerY": "50%",
        "id": "lblTitle",
        "isVisible": true,
        "skin": "CopyslLabel0acaf0be04c9c4b",
        "text": "Road-IT",
        "textStyle": {
            "letterSpacing": 0,
            "strikeThrough": false
        },
        "width": kony.flex.USE_PREFFERED_SIZE
    }, {
        "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
        "padding": [0, 0, 0, 0],
        "paddingInPixel": false
    }, {
        "textCopyable": false
    });
    var Image08cd7bcf5747041 = new kony.ui.Image2({
        "centerY": "50%",
        "height": "90%",
        "id": "Image08cd7bcf5747041",
        "isVisible": true,
        "left": "3%",
        "onTouchEnd": AS_Image_86b356dea5b14a5ba6a205c0fae04a37,
        "skin": "slImage",
        "src": "menuwhite.png",
        "top": "8dp",
        "width": "12%",
        "zIndex": 1
    }, {
        "imageScaleMode": constants.IMAGE_SCALE_MODE_MAINTAIN_ASPECT_RATIO,
        "padding": [0, 0, 0, 0],
        "paddingInPixel": false
    }, {});
    FlexContainer0af4ba12e07cb44.add(
    lblTitle, Image08cd7bcf5747041);
    var flxBody = new kony.ui.FlexContainer({
        "autogrowMode": kony.flex.AUTOGROW_NONE,
        "clipBounds": true,
        "height": "92%",
        "id": "flxBody",
        "isVisible": true,
        "layoutType": kony.flex.FLOW_VERTICAL,
        "left": "0%",
        "skin": "flxOUT",
        "top": "8%",
        "width": "100%"
    }, {}, {});
    flxBody.setDefaultUnit(kony.flex.DP);
    var FlexContainer08e01a4eb5bbc4e = new kony.ui.FlexContainer({
        "autogrowMode": kony.flex.AUTOGROW_NONE,
        "clipBounds": true,
        "height": "23%",
        "id": "FlexContainer08e01a4eb5bbc4e",
        "isVisible": true,
        "layoutType": kony.flex.FLOW_VERTICAL,
        "left": "0dp",
        "skin": "slFbox",
        "top": "0dp",
        "width": "100%",
        "zIndex": 1
    }, {}, {});
    FlexContainer08e01a4eb5bbc4e.setDefaultUnit(kony.flex.DP);
    var lblWelcomeUser = new kony.ui.Label({
        "id": "lblWelcomeUser",
        "isVisible": true,
        "right": "5%",
        "skin": "sknlbl281c3f64",
        "text": "Welcome Karthik",
        "textStyle": {
            "letterSpacing": 0,
            "strikeThrough": false
        },
        "top": "3%",
        "width": "32%"
    }, {
        "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
        "padding": [0, 0, 0, 0],
        "paddingInPixel": false
    }, {
        "textCopyable": false
    });
    var btnStartTrip = new kony.ui.Button({
        "centerX": "50.00%",
        "focusSkin": "sknBtnFocus",
        "height": "32%",
        "id": "btnStartTrip",
        "isVisible": true,
        "left": "5%",
        "onClick": AS_Button_d8418e85c44b47409ef7b23b67215acd,
        "skin": "sknBtnFF5D6E",
        "text": "Start Trip",
        "top": "4%",
        "width": "80%"
    }, {
        "contentAlignment": constants.CONTENT_ALIGN_CENTER,
        "displayText": true,
        "padding": [0, 0, 0, 0],
        "paddingInPixel": false
    }, {});
    var lblLastTrip = new kony.ui.Label({
        "centerX": "50%",
        "height": "15%",
        "id": "lblLastTrip",
        "isVisible": true,
        "left": "0dp",
        "skin": "sknlblCN32FFFFFF",
        "text": "Your Last Trip Ride Quality was 7/10",
        "textStyle": {
            "letterSpacing": 0,
            "strikeThrough": false
        },
        "top": "10%",
        "width": "79%",
        "zIndex": 1
    }, {
        "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
        "padding": [0, 0, 0, 0],
        "paddingInPixel": false
    }, {
        "textCopyable": false
    });
    FlexContainer08e01a4eb5bbc4e.add(
    lblWelcomeUser, btnStartTrip, lblLastTrip);
    var FlexContainer08c03aa7531cd40 = new kony.ui.FlexContainer({
        "autogrowMode": kony.flex.AUTOGROW_NONE,
        "clipBounds": true,
        "height": "7%",
        "id": "FlexContainer08c03aa7531cd40",
        "isVisible": true,
        "layoutType": kony.flex.FREE_FORM,
        "left": "0dp",
        "skin": "flexHead",
        "top": "0%",
        "width": "100%",
        "zIndex": 1
    }, {}, {});
    FlexContainer08c03aa7531cd40.setDefaultUnit(kony.flex.DP);
    var lblSummary = new kony.ui.Label({
        "centerY": "50%",
        "id": "lblSummary",
        "isVisible": true,
        "left": "5%",
        "skin": "sknlblCN32FFFFFF",
        "text": "Summary",
        "textStyle": {
            "letterSpacing": 0,
            "strikeThrough": false
        },
        "top": "0dp",
        "width": kony.flex.USE_PREFFERED_SIZE,
        "zIndex": 1
    }, {
        "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
        "padding": [0, 0, 0, 0],
        "paddingInPixel": false
    }, {
        "textCopyable": false
    });
    FlexContainer08c03aa7531cd40.add(
    lblSummary);
    var flxSummary = new kony.ui.FlexContainer({
        "autogrowMode": kony.flex.AUTOGROW_NONE,
        "clipBounds": true,
        "height": "50%",
        "id": "flxSummary",
        "isVisible": true,
        "layoutType": kony.flex.FREE_FORM,
        "left": "0dp",
        "skin": "sknflxnoborder",
        "top": "0%",
        "width": "100%",
        "zIndex": 1
    }, {}, {});
    flxSummary.setDefaultUnit(kony.flex.DP);
    var FlexContainer04dcec7287e0c4a = new kony.ui.FlexContainer({
        "autogrowMode": kony.flex.AUTOGROW_NONE,
        "clipBounds": true,
        "focusSkin": "CopyBGFFFFFF0be3721d241cb45",
        "height": "40%",
        "id": "FlexContainer04dcec7287e0c4a",
        "isVisible": true,
        "layoutType": kony.flex.FREE_FORM,
        "left": "6.30%",
        "onTouchEnd": AS_FlexContainer_cee312eb185a41da86eabc9f4b069e53,
        "skin": "CopyBGFFFFFF0f5b725090f2148",
        "top": "6.33%",
        "width": "40%",
        "zIndex": 30
    }, {}, {});
    FlexContainer04dcec7287e0c4a.setDefaultUnit(kony.flex.DP);
    var Label03f1d747e92b743 = new kony.ui.Label({
        "centerX": "50%",
        "id": "Label03f1d747e92b743",
        "isVisible": true,
        "skin": "Copysknlbl0d30bd854fdea42",
        "text": "Trips",
        "textStyle": {
            "letterSpacing": 0,
            "strikeThrough": false
        },
        "top": "25%",
        "width": kony.flex.USE_PREFFERED_SIZE
    }, {
        "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
        "padding": [0, 0, 0, 0],
        "paddingInPixel": false
    }, {
        "textCopyable": false
    });
    var Label080cac56f82a24b = new kony.ui.Label({
        "centerX": "50%",
        "centerY": "58%",
        "height": "26%",
        "id": "Label080cac56f82a24b",
        "isVisible": true,
        "left": "56dp",
        "skin": "CopysknlblCN015f60169da104c",
        "text": "27",
        "textStyle": {
            "letterSpacing": 0,
            "strikeThrough": false
        },
        "top": "45dp",
        "width": kony.flex.USE_PREFFERED_SIZE,
        "zIndex": 1
    }, {
        "contentAlignment": constants.CONTENT_ALIGN_CENTER,
        "padding": [0, 0, 0, 0],
        "paddingInPixel": false
    }, {
        "textCopyable": false
    });
    FlexContainer04dcec7287e0c4a.add(
    Label03f1d747e92b743, Label080cac56f82a24b);
    var CopyFlexContainer0e760f5f3cb8745 = new kony.ui.FlexContainer({
        "autogrowMode": kony.flex.AUTOGROW_NONE,
        "clipBounds": true,
        "focusSkin": "CopyBGFFFFFF0323526f32f6f47",
        "height": "40%",
        "id": "CopyFlexContainer0e760f5f3cb8745",
        "isVisible": true,
        "layoutType": kony.flex.FREE_FORM,
        "left": "52.66%",
        "skin": "CopyBGFFFFFF031b24f5ea0e748",
        "top": "6.33%",
        "width": "40%"
    }, {}, {});
    CopyFlexContainer0e760f5f3cb8745.setDefaultUnit(kony.flex.DP);
    var CopyLabel00b07ff6ea57741 = new kony.ui.Label({
        "centerX": "50%",
        "id": "CopyLabel00b07ff6ea57741",
        "isVisible": true,
        "skin": "Copysknlbl0b5e7205a2e004b",
        "text": "Bumps Encountered",
        "textStyle": {
            "letterSpacing": 0,
            "strikeThrough": false
        },
        "top": "20%",
        "width": "90%"
    }, {
        "contentAlignment": constants.CONTENT_ALIGN_CENTER,
        "padding": [0, 0, 0, 0],
        "paddingInPixel": false
    }, {
        "textCopyable": false
    });
    var CopyLabel038fba546b6d94d = new kony.ui.Label({
        "centerX": "50%",
        "centerY": "68%",
        "id": "CopyLabel038fba546b6d94d",
        "isVisible": true,
        "left": "56dp",
        "skin": "CopysknlblCN070a408eaf7ae41",
        "text": "789",
        "textStyle": {
            "letterSpacing": 0,
            "strikeThrough": false
        },
        "top": "55%",
        "width": kony.flex.USE_PREFFERED_SIZE,
        "zIndex": 1
    }, {
        "contentAlignment": constants.CONTENT_ALIGN_CENTER,
        "padding": [0, 0, 0, 0],
        "paddingInPixel": false
    }, {
        "textCopyable": false
    });
    CopyFlexContainer0e760f5f3cb8745.add(
    CopyLabel00b07ff6ea57741, CopyLabel038fba546b6d94d);
    var CopyFlexContainer06973b690cdfd4d = new kony.ui.FlexContainer({
        "autogrowMode": kony.flex.AUTOGROW_NONE,
        "clipBounds": true,
        "focusSkin": "CopyBGFFFFFF08ace046ab98241",
        "height": "40%",
        "id": "CopyFlexContainer06973b690cdfd4d",
        "isVisible": true,
        "layoutType": kony.flex.FREE_FORM,
        "left": "52.66%",
        "skin": "CopyBGFFFFFF02a110bdbf4654f",
        "top": "52.66%",
        "width": "40%"
    }, {}, {});
    CopyFlexContainer06973b690cdfd4d.setDefaultUnit(kony.flex.DP);
    var CopyLabel0820fef94b9df46 = new kony.ui.Label({
        "centerX": "50%",
        "id": "CopyLabel0820fef94b9df46",
        "isVisible": true,
        "skin": "Copysknlbl0312b01313a324b",
        "text": "Favourite Routes",
        "textStyle": {
            "letterSpacing": 0,
            "strikeThrough": false
        },
        "top": "25%",
        "width": kony.flex.USE_PREFFERED_SIZE
    }, {
        "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
        "padding": [0, 0, 0, 0],
        "paddingInPixel": false
    }, {
        "textCopyable": false
    });
    var CopyLabel0c7e239b21f0143 = new kony.ui.Label({
        "centerX": "50%",
        "centerY": "58%",
        "id": "CopyLabel0c7e239b21f0143",
        "isVisible": true,
        "left": "56dp",
        "skin": "CopysknlblCN0e2a098b3605247",
        "text": "6",
        "textStyle": {
            "letterSpacing": 0,
            "strikeThrough": false
        },
        "top": "45dp",
        "width": kony.flex.USE_PREFFERED_SIZE,
        "zIndex": 1
    }, {
        "contentAlignment": constants.CONTENT_ALIGN_CENTER,
        "padding": [0, 0, 0, 0],
        "paddingInPixel": false
    }, {
        "textCopyable": false
    });
    CopyFlexContainer06973b690cdfd4d.add(
    CopyLabel0820fef94b9df46, CopyLabel0c7e239b21f0143);
    var CopyFlexContainer0c29ac9a120954c = new kony.ui.FlexContainer({
        "autogrowMode": kony.flex.AUTOGROW_NONE,
        "clipBounds": true,
        "focusSkin": "CopyBGFFFFFF0fe6a9d80e4d149",
        "height": "40%",
        "id": "CopyFlexContainer0c29ac9a120954c",
        "isVisible": true,
        "layoutType": kony.flex.FREE_FORM,
        "left": "6.33%",
        "onTouchEnd": AS_FlexContainer_b644e4a72dd747e4ac363ccdfb151ead,
        "skin": "CopyBGFFFFFF0ff758620b6ba4b",
        "top": "52.66%",
        "width": "40%"
    }, {}, {});
    CopyFlexContainer0c29ac9a120954c.setDefaultUnit(kony.flex.DP);
    var CopyLabel047fd651cc2f14c = new kony.ui.Label({
        "centerX": "50%",
        "id": "CopyLabel047fd651cc2f14c",
        "isVisible": true,
        "skin": "Copysknlbl061dfd99dd93e40",
        "text": "Issues Reported",
        "textStyle": {
            "letterSpacing": 0,
            "strikeThrough": false
        },
        "top": "25%",
        "width": kony.flex.USE_PREFFERED_SIZE
    }, {
        "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
        "padding": [0, 0, 0, 0],
        "paddingInPixel": false
    }, {
        "textCopyable": false
    });
    var CopyLabel012196268238c4a = new kony.ui.Label({
        "centerX": "50%",
        "centerY": "58%",
        "id": "CopyLabel012196268238c4a",
        "isVisible": true,
        "left": "56dp",
        "skin": "CopysknlblCN04c98b72f092e41",
        "text": "4",
        "textStyle": {
            "letterSpacing": 0,
            "strikeThrough": false
        },
        "top": "45dp",
        "width": kony.flex.USE_PREFFERED_SIZE,
        "zIndex": 1
    }, {
        "contentAlignment": constants.CONTENT_ALIGN_CENTER,
        "padding": [0, 0, 0, 0],
        "paddingInPixel": false
    }, {
        "textCopyable": false
    });
    CopyFlexContainer0c29ac9a120954c.add(
    CopyLabel047fd651cc2f14c, CopyLabel012196268238c4a);
    flxSummary.add(
    FlexContainer04dcec7287e0c4a, CopyFlexContainer0e760f5f3cb8745, CopyFlexContainer06973b690cdfd4d, CopyFlexContainer0c29ac9a120954c);
    var FlexContainer0327f97933daf4a = new kony.ui.FlexContainer({
        "autogrowMode": kony.flex.AUTOGROW_NONE,
        "clipBounds": true,
        "height": "8%",
        "id": "FlexContainer0327f97933daf4a",
        "isVisible": true,
        "layoutType": kony.flex.FREE_FORM,
        "left": "0dp",
        "skin": "Copysknflxnoborder0c6b3a5c398f041",
        "top": "0dp",
        "width": "100%",
        "zIndex": 1
    }, {}, {});
    FlexContainer0327f97933daf4a.setDefaultUnit(kony.flex.DP);
    var Label0155e722d822a41 = new kony.ui.Label({
        "centerY": "50%",
        "id": "Label0155e722d822a41",
        "isVisible": true,
        "left": "10%",
        "skin": "Copysknlbl02013d7afa7ef45",
        "text": "Ensure Privacy",
        "textStyle": {
            "letterSpacing": 0,
            "strikeThrough": false
        },
        "top": "0dp",
        "width": kony.flex.USE_PREFFERED_SIZE,
        "zIndex": 1
    }, {
        "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
        "padding": [0, 0, 0, 0],
        "paddingInPixel": false
    }, {
        "textCopyable": false
    });
    var Switch0c15b97a05a7c4c = new kony.ui.Switch({
        "centerY": "50%",
        "height": "32dp",
        "id": "Switch0c15b97a05a7c4c",
        "isVisible": true,
        "leftSideText": "ON",
        "onSlide": AS_Switch_22af811982ee498bad506ed02582910b,
        "right": "10%",
        "rightSideText": "OFF",
        "selectedIndex": 1,
        "skin": "slSwitch",
        "top": "0dp",
        "width": "55dp",
        "zIndex": 1
    }, {
        "padding": [0, 0, 0, 0],
        "paddingInPixel": false
    }, {});
    FlexContainer0327f97933daf4a.add(
    Label0155e722d822a41, Switch0c15b97a05a7c4c);
    var FlexContainer008fbc811371b40 = new kony.ui.FlexContainer({
        "autogrowMode": kony.flex.AUTOGROW_NONE,
        "clipBounds": true,
        "height": "12%",
        "id": "FlexContainer008fbc811371b40",
        "isVisible": true,
        "layoutType": kony.flex.FREE_FORM,
        "left": "0dp",
        "skin": "sknflxnoborder",
        "top": "0dp",
        "width": "100%",
        "zIndex": 1
    }, {}, {});
    FlexContainer008fbc811371b40.setDefaultUnit(kony.flex.DP);
    var cameraPic = new kony.ui.Camera({
        "centerX": "50%",
        "focusSkin": "CopyslCamera040c6e91e21e44a",
        "height": "42dp",
        "id": "cameraPic",
        "isVisible": true,
        "left": "50dp",
        "onCapture": AS_Camera_5aa7c77de4154cfe96883eef4a30e19d,
        "skin": "CopyslCamera0cd9ad8dd14fe48",
        "text": "Report Issue",
        "top": "15dp",
        "width": "80%",
        "zIndex": 1
    }, {
        "contentAlignment": constants.CONTENT_ALIGN_CENTER,
        "padding": [0, 0, 0, 0],
        "paddingInPixel": false
    }, {
        "accessMode": constants.CAMERA_IMAGE_ACCESS_MODE_PUBLIC,
        "enableOverlay": false,
        "enablePhotoCropFeature": false
    });
    FlexContainer008fbc811371b40.add(
    cameraPic);
    flxBody.add(
    FlexContainer08e01a4eb5bbc4e, FlexContainer08c03aa7531cd40, flxSummary, FlexContainer0327f97933daf4a, FlexContainer008fbc811371b40);
    flxOuter.add(
    FlexContainer0af4ba12e07cb44, flxBody);
    frmDashboard.add(
    flxMenuMain, flxOuter);
};

function frmDashboardGlobals() {
    frmDashboard = new kony.ui.Form2({
        "addWidgets": addWidgetsfrmDashboard,
        "bounces": false,
        "enableScrolling": false,
        "enabledForIdleTimeout": false,
        "id": "frmDashboard",
        "layoutType": kony.flex.FREE_FORM,
        "needAppMenu": false,
        "skin": "CopyslForm0b02761fac20f49"
    }, {
        "displayOrientation": constants.FORM_DISPLAY_ORIENTATION_PORTRAIT,
        "layoutType": kony.flex.FREE_FORM,
        "padding": [0, 0, 0, 0],
        "paddingInPixel": false
    }, {
        "footerOverlap": false,
        "headerOverlap": false,
        "menuPosition": constants.FORM_MENU_POSITION_AFTER_APPMENU,
        "retainScrollPosition": false,
        "titleBar": false,
        "titleBarSkin": "slTitleBar",
        "windowSoftInputMode": constants.FORM_ADJUST_PAN
    });
};