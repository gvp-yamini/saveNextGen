function AS_Button_d8418e85c44b47409ef7b23b67215acd(eventobject) {
    frmStartTrip.lblEndTImeValue.setVisibility(false);
    frmStartTrip.flxQuality.setVisibility(false);
    frmStartTrip.lblBumpsCount.text = 0;
    frmStartTrip.btnEndTrip.setVisibility(true);
    frmStartTrip.show();
    regAccEvent();
}