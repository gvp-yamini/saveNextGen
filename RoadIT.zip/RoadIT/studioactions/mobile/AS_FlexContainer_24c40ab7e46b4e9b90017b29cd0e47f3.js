function AS_FlexContainer_24c40ab7e46b4e9b90017b29cd0e47f3(eventobject, x, y) {
    onClickHamburgerMenuOriginal(kony.application.getCurrentForm());
    frmDashboard.show();
}