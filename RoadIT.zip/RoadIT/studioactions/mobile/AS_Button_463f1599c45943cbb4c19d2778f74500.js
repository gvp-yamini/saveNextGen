function AS_Button_463f1599c45943cbb4c19d2778f74500(eventobject) {
    alert("Thank You!\n You will recieve a notification when a campaign is launched in that area");
    frmTripList.show();
}