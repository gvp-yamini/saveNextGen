function AS_Image_ddef13c5da914445bf14544f8789b59a(eventobject, x, y) {
    getHamburgerMenu();
}