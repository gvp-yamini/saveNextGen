function AS_FlexContainer_0c10620f49184e2d9286765f14c654aa(eventobject, x, y) {
    onClickHamburgerMenuOriginal(kony.application.getCurrentForm());
    frmTripList.show();
}