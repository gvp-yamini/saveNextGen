function initializetmpCardContractor() {
    FlexContainer0266fa20c665144 = new kony.ui.FlexContainer({
        "autogrowMode": kony.flex.AUTOGROW_NONE,
        "clipBounds": true,
        "height": "125dp",
        "id": "FlexContainer0266fa20c665144",
        "isVisible": true,
        "layoutType": kony.flex.FREE_FORM,
        "skin": "slFbox"
    }, {}, {});
    FlexContainer0266fa20c665144.setDefaultUnit(kony.flex.DP);
    var flxMain = new kony.ui.FlexContainer({
        "autogrowMode": kony.flex.AUTOGROW_NONE,
        "centerX": "50%",
        "centerY": "50%",
        "clipBounds": true,
        "height": "120dp",
        "id": "flxMain",
        "isVisible": true,
        "layoutType": kony.flex.FREE_FORM,
        "left": "0",
        "skin": "CopyslFbox0cb57e36de79c47",
        "top": "0",
        "width": "97%"
    }, {}, {});
    flxMain.setDefaultUnit(kony.flex.DP);
    var FlexContainer088bbdb12387547 = new kony.ui.FlexContainer({
        "autogrowMode": kony.flex.AUTOGROW_NONE,
        "centerY": "50%",
        "clipBounds": true,
        "height": "80%",
        "id": "FlexContainer088bbdb12387547",
        "isVisible": true,
        "layoutType": kony.flex.FREE_FORM,
        "left": "3%",
        "skin": "CopyslFbox02220fe6f344b46",
        "top": "24dp",
        "width": "25%"
    }, {}, {});
    FlexContainer088bbdb12387547.setDefaultUnit(kony.flex.DP);
    var Image0fe6d245e6f994c = new kony.ui.Image2({
        "height": "100%",
        "id": "Image0fe6d245e6f994c",
        "isVisible": true,
        "left": "0dp",
        "skin": "slImage",
        "src": "image2.png",
        "top": "0dp",
        "width": "100%"
    }, {
        "imageScaleMode": constants.IMAGE_SCALE_MODE_MAINTAIN_ASPECT_RATIO,
        "padding": [0, 0, 0, 0],
        "paddingInPixel": false
    }, {});
    FlexContainer088bbdb12387547.add(
    Image0fe6d245e6f994c);
    var Label06dfb540e869848 = new kony.ui.Label({
        "id": "Label06dfb540e869848",
        "isVisible": true,
        "left": "35%",
        "skin": "CopysknlblValue04b91bec51a904a",
        "text": "Mark Bill",
        "textStyle": {
            "letterSpacing": 0,
            "strikeThrough": false
        },
        "top": "20%",
        "width": kony.flex.USE_PREFFERED_SIZE,
        "zIndex": 1
    }, {
        "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
        "padding": [0, 0, 0, 0],
        "paddingInPixel": false
    }, {
        "textCopyable": false
    });
    var CopyLabel02e8109dc084d44 = new kony.ui.Label({
        "id": "CopyLabel02e8109dc084d44",
        "isVisible": true,
        "left": "80%",
        "skin": "CopysknlblValue04b91bec51a904a",
        "text": "Mark Bill",
        "textStyle": {
            "letterSpacing": 0,
            "strikeThrough": false
        },
        "top": "65%",
        "width": kony.flex.USE_PREFFERED_SIZE,
        "zIndex": 1
    }, {
        "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
        "padding": [0, 0, 0, 0],
        "paddingInPixel": false
    }, {
        "textCopyable": false
    });
    var Label0fde795e17a674d = new kony.ui.Label({
        "id": "Label0fde795e17a674d",
        "isVisible": true,
        "left": "35%",
        "skin": "CopysknLabel07269f37f49d947",
        "text": "L&T Works",
        "textStyle": {
            "letterSpacing": 0,
            "strikeThrough": false
        },
        "top": "40%",
        "width": kony.flex.USE_PREFFERED_SIZE,
        "zIndex": 1
    }, {
        "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
        "padding": [0, 0, 0, 0],
        "paddingInPixel": false
    }, {
        "textCopyable": false
    });
    var FlexContainer0758cc1a9369245 = new kony.ui.FlexContainer({
        "autogrowMode": kony.flex.AUTOGROW_NONE,
        "clipBounds": true,
        "height": "30%",
        "id": "FlexContainer0758cc1a9369245",
        "isVisible": true,
        "layoutType": kony.flex.FLOW_HORIZONTAL,
        "left": "34%",
        "skin": "slFbox",
        "top": "56%",
        "width": "60.05%",
        "zIndex": 1
    }, {}, {});
    FlexContainer0758cc1a9369245.setDefaultUnit(kony.flex.DP);
    var Image09d4297c0dd464f = new kony.ui.Image2({
        "height": "100%",
        "id": "Image09d4297c0dd464f",
        "isVisible": true,
        "left": "0%",
        "skin": "slImage",
        "src": "rated.png",
        "top": "3dp",
        "width": "14%"
    }, {
        "imageScaleMode": constants.IMAGE_SCALE_MODE_MAINTAIN_ASPECT_RATIO,
        "padding": [0, 0, 0, 0],
        "paddingInPixel": false
    }, {});
    var CopyImage0190495ce5bc748 = new kony.ui.Image2({
        "height": "100%",
        "id": "CopyImage0190495ce5bc748",
        "isVisible": true,
        "left": "0%",
        "skin": "slImage",
        "src": "rated.png",
        "top": "3dp",
        "width": "14%"
    }, {
        "imageScaleMode": constants.IMAGE_SCALE_MODE_MAINTAIN_ASPECT_RATIO,
        "padding": [0, 0, 0, 0],
        "paddingInPixel": false
    }, {});
    var CopyImage02aeda0506e3b4b = new kony.ui.Image2({
        "height": "100%",
        "id": "CopyImage02aeda0506e3b4b",
        "isVisible": true,
        "left": "0%",
        "skin": "slImage",
        "src": "rated.png",
        "top": "3dp",
        "width": "14%"
    }, {
        "imageScaleMode": constants.IMAGE_SCALE_MODE_MAINTAIN_ASPECT_RATIO,
        "padding": [0, 0, 0, 0],
        "paddingInPixel": false
    }, {});
    var CopyImage0e183017d17f642 = new kony.ui.Image2({
        "height": "100%",
        "id": "CopyImage0e183017d17f642",
        "isVisible": true,
        "left": "0%",
        "skin": "slImage",
        "src": "rated.png",
        "top": "3dp",
        "width": "14%"
    }, {
        "imageScaleMode": constants.IMAGE_SCALE_MODE_MAINTAIN_ASPECT_RATIO,
        "padding": [0, 0, 0, 0],
        "paddingInPixel": false
    }, {});
    var CopyImage0113dd71922bd4b = new kony.ui.Image2({
        "height": "100%",
        "id": "CopyImage0113dd71922bd4b",
        "isVisible": true,
        "left": "0%",
        "skin": "slImage",
        "src": "unrated.png",
        "top": "3dp",
        "width": "14%"
    }, {
        "imageScaleMode": constants.IMAGE_SCALE_MODE_MAINTAIN_ASPECT_RATIO,
        "padding": [0, 0, 0, 0],
        "paddingInPixel": false
    }, {});
    FlexContainer0758cc1a9369245.add(
    Image09d4297c0dd464f, CopyImage0190495ce5bc748, CopyImage02aeda0506e3b4b, CopyImage0e183017d17f642, CopyImage0113dd71922bd4b);
    flxMain.add(
    FlexContainer088bbdb12387547, Label06dfb540e869848, CopyLabel02e8109dc084d44, Label0fde795e17a674d, FlexContainer0758cc1a9369245);
    FlexContainer0266fa20c665144.add(
    flxMain);
}