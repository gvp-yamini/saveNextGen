//actions.js file 
function AS_Button_0566ea4431554e99996cd3b99ba28534(eventobject) {
    frmStartTrip.lblEndTImeValue.setVisibility(true);
    frmStartTrip.flxQuality.setVisibility(true);
    frmStartTrip.btnEndTrip.setVisibility(false);
    kony.accelerometer.unregisterAccelerationEvents(["shake"]);
    shakeCount = 0;
}
function AS_Button_065a51e2881a4a539f0ad8e1a85b732b(eventobject) {
    alert("Issue Submitted Successfully");
    frmDashboard.show();
    /*if(isFromST)
  {
    frmStartTrip.show();
  }
else
  {
	frmDashboard.show();    
  }

*/
}
function AS_Button_390df827719840cf942c35e6522b4ffd(eventobject, context) {
    frmContribute.show();
}
function AS_Button_43ad23f6973742e88aeb3f43d3c24750(eventobject) {
    //frmDashboard.headers[0].lblTitle.text="Road-IT";
    frmDashboard.show();
}
function AS_Button_463f1599c45943cbb4c19d2778f74500(eventobject) {
    alert("Thank You!\n You will recieve a notification when a campaign is launched in that area");
    frmTripList.show();
}
function AS_Button_d8418e85c44b47409ef7b23b67215acd(eventobject) {
    frmStartTrip.lblEndTImeValue.setVisibility(false);
    frmStartTrip.flxQuality.setVisibility(false);
    frmStartTrip.lblBumpsCount.text = 0;
    frmStartTrip.btnEndTrip.setVisibility(true);
    frmStartTrip.show();
    regAccEvent();
}
function AS_Camera_5aa7c77de4154cfe96883eef4a30e19d(eventobject) {
    isFromST = false;
    frmIssue.show();
    frmIssue.ImgCaptured.rawBytes = frmDashboard.cameraPic.rawBytes;
    frmIssue.btnStartTrip.setVisibility(true);
    frmIssue.TextArea08ea20b91246d44.setEnabled(true);
}
function AS_Camera_c175b33cea4144b181141e233d502ae3(eventobject) {
    //isFromST=true;
    frmIssue.show();
    frmIssue.ImgCaptured.rawBytes = frmStartTrip.cameraPic.rawBytes;
    frmIssue.btnStartTrip.setVisibility(true);
    frmIssue.TextArea08ea20b91246d44.setEnabled(true);
}
function AS_FlexContainer_023d39feade44fbabf6dca8f684b6775(eventobject, x, y) {
    onClickHamburgerMenuOriginal(kony.application.getCurrentForm());
    frmIssues.show();
}
function AS_FlexContainer_0c10620f49184e2d9286765f14c654aa(eventobject, x, y) {
    onClickHamburgerMenuOriginal(kony.application.getCurrentForm());
    frmTripList.show();
}
function AS_FlexContainer_24c40ab7e46b4e9b90017b29cd0e47f3(eventobject, x, y) {
    onClickHamburgerMenuOriginal(kony.application.getCurrentForm());
    frmDashboard.show();
}
function AS_FlexContainer_3b286f168fdc47cf9879d483cf9b4748(eventobject, x, y) {
    onClickHamburgerMenuOriginal(kony.application.getCurrentForm());
    frmLogin.show();
}
function AS_FlexContainer_3bfba7ab121041fb8626bbf17da2732b(eventobject, x, y) {
    onClickHamburgerMenuOriginal(kony.application.getCurrentForm());
    frmLogin.show();
}
function AS_FlexContainer_80196141f9f9403d99bcea3b560a7bf7(eventobject, x, y) {
    onClickHamburgerMenuOriginal(kony.application.getCurrentForm());
    frmTripList.show();
}
function AS_FlexContainer_8f8c90698d66480dad592dd0c1ca2b28(eventobject, x, y) {
    onClickHamburgerMenuOriginal(kony.application.getCurrentForm());
    frmContractors.show();
}
function AS_FlexContainer_982c447706ea47b591582359020e3c7c(eventobject, x, y) {
    onClickHamburgerMenuOriginal(kony.application.getCurrentForm());
    frmDashboard.show();
}
function AS_FlexContainer_9f8816ad01314494be7c369ee7fafbe3(eventobject, x, y) {
    onClickHamburgerMenuOriginal(kony.application.getCurrentForm());
    frmDashboard.show();
}
function AS_FlexContainer_a92a718fb09949138395dc9aade39fdc(eventobject, x, y) {
    onClickHamburgerMenuOriginal(kony.application.getCurrentForm());
    frmLogin.show();
}
function AS_FlexContainer_adc0d8295ff646dd88a6c936ddf57e1b(eventobject, x, y) {
    onClickHamburgerMenuOriginal(kony.application.getCurrentForm());
    frmDashboard.show();
}
function AS_FlexContainer_b14a33d384c345899b5a1e6f5d950142(eventobject, x, y) {
    onClickHamburgerMenuOriginal(kony.application.getCurrentForm());
    frmTripList.show();
}
function AS_FlexContainer_b644e4a72dd747e4ac363ccdfb151ead(eventobject, x, y) {
    frmIssues.show();
}
function AS_FlexContainer_b8f4e47ce98742c98169b81e39eb45f7(eventobject, x, y) {
    onClickHamburgerMenuOriginal(kony.application.getCurrentForm());
    frmContractors.show();
}
function AS_FlexContainer_cee312eb185a41da86eabc9f4b069e53(eventobject, x, y) {
    frmTripList.show();
}
function AS_FlexContainer_dcfc353f260d47fc88e87e3a4a33d342(eventobject, x, y) {
    onClickHamburgerMenuOriginal(kony.application.getCurrentForm());
    frmContractors.show();
}
function AS_FlexContainer_dd1675a0675f43f8974bad9a7b6c3754(eventobject, x, y) {
    onClickHamburgerMenuOriginal(kony.application.getCurrentForm());
    frmLogin.show();
}
function AS_FlexContainer_e66597f3c32f442c98372d5aa2b5ca19(eventobject, x, y) {
    onClickHamburgerMenuOriginal(kony.application.getCurrentForm());
    frmIssues.show();
}
function AS_FlexContainer_e6ebc0c5f0c947c1b35fca5498cb8df1(eventobject, x, y) {
    onClickHamburgerMenuOriginal(kony.application.getCurrentForm());
    frmIssues.show();
}
function AS_FlexContainer_f12ce7f111f747b69c41800b31725b99(eventobject, x, y) {
    onClickHamburgerMenuOriginal(kony.application.getCurrentForm());
    frmIssues.show();
}
function AS_FlexContainer_f6917a6b5a5742e8b7bb058483bfbbd4(eventobject, x, y) {
    onClickHamburgerMenuOriginal(kony.application.getCurrentForm());
    frmTripList.show();
}
function AS_FlexContainer_fed67b330718437db918eecc9fe960a7(eventobject, x, y) {
    onClickHamburgerMenuOriginal(kony.application.getCurrentForm());
    frmContractors.show();
}
function AS_Image_0a4b39243b774e3ab3a6f087a7e6f920(eventobject, x, y) {
    getHamburgerMenu();
}
function AS_Image_636198c6b2cb4170937e895827395f5c(eventobject, x, y) {
    getHamburgerMenu();
}
function AS_Image_86b356dea5b14a5ba6a205c0fae04a37(eventobject, x, y) {
    getHamburgerMenu();
}
function AS_Image_874ab94c1c4f4a01b1f1def540e5152f(eventobject, x, y) {
    var Form = kony.application.getPreviousForm();
    Form.show();
}
function AS_Image_9a9f42409ea344d993a42b4237692602(eventobject, x, y) {
    var prevForm = kony.application.getPreviousForm();
    prevForm.show();
}
function AS_Image_d7498497efad40809382649a907c9ed3(eventobject, x, y) {
    frmDashboard.show();
}
function AS_Image_ddef13c5da914445bf14544f8789b59a(eventobject, x, y) {
    getHamburgerMenu();
}
function AS_Segment_bdd3f10f5dc54ffbb9c9b33bd33eb050(eventobject, sectionNumber, rowNumber) {
    frmIssue.ImgCaptured.src = "tree.png";
    frmIssue.btnStartTrip.setVisibility(false);
    frmIssue.TextArea08ea20b91246d44.text = "A tree fell down on the road and there is traffic jam.";
    frmIssue.TextArea08ea20b91246d44.setEnabled(false);
    frmIssue.show();
}
function AS_Segment_f0d27e0616e44052acb873c91e33f35b(eventobject, sectionNumber, rowNumber) {
    alert(frmIssues.segIssues.data);
}
function AS_Switch_22af811982ee498bad506ed02582910b(eventobject) {
    if (frmDashboard.Switch0c15b97a05a7c4c.selectedIndex === 0) alert("Sure! Data will not be captured outside your favourite zone");
}