function AS_FlexContainer_9f8816ad01314494be7c369ee7fafbe3(eventobject, x, y) {
    onClickHamburgerMenuOriginal(kony.application.getCurrentForm());
    frmDashboard.show();
}