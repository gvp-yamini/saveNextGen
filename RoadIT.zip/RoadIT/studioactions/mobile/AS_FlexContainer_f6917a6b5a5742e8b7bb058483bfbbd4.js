function AS_FlexContainer_f6917a6b5a5742e8b7bb058483bfbbd4(eventobject, x, y) {
    onClickHamburgerMenuOriginal(kony.application.getCurrentForm());
    frmTripList.show();
}