function AS_Image_9a9f42409ea344d993a42b4237692602(eventobject, x, y) {
    var prevForm = kony.application.getPreviousForm();
    prevForm.show();
}