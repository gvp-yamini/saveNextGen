function AS_FlexContainer_dd1675a0675f43f8974bad9a7b6c3754(eventobject, x, y) {
    onClickHamburgerMenuOriginal(kony.application.getCurrentForm());
    frmLogin.show();
}