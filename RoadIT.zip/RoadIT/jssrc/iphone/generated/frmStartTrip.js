function addWidgetsfrmStartTrip() {
    frmStartTrip.setDefaultUnit(kony.flex.DP);
    var flxOuter = new kony.ui.FlexContainer({
        "autogrowMode": kony.flex.AUTOGROW_NONE,
        "clipBounds": true,
        "height": "92%",
        "id": "flxOuter",
        "isVisible": true,
        "layoutType": kony.flex.FREE_FORM,
        "left": "0dp",
        "skin": "sknflxnoborder",
        "top": "8%",
        "width": "100%"
    }, {}, {});
    flxOuter.setDefaultUnit(kony.flex.DP);
    var FlexContainer08d2f4c72bc1640 = new kony.ui.FlexContainer({
        "autogrowMode": kony.flex.AUTOGROW_NONE,
        "clipBounds": true,
        "height": "15%",
        "id": "FlexContainer08d2f4c72bc1640",
        "isVisible": true,
        "layoutType": kony.flex.FREE_FORM,
        "left": "0dp",
        "skin": "slFbox",
        "top": "0dp",
        "width": "100%"
    }, {}, {});
    FlexContainer08d2f4c72bc1640.setDefaultUnit(kony.flex.DP);
    var lblStartTime = new kony.ui.Label({
        "id": "lblStartTime",
        "isVisible": true,
        "left": "5%",
        "skin": "CopysknLabel0f5f4143a876d48",
        "text": "Start Time:",
        "top": "25%",
        "width": kony.flex.USE_PREFFERED_SIZE
    }, {
        "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
        "padding": [0, 0, 0, 0],
        "paddingInPixel": false
    }, {
        "textCopyable": false,
        "wrapping": constants.WIDGET_TEXT_WORD_WRAP
    });
    var lblEndTImeValue = new kony.ui.Label({
        "id": "lblEndTImeValue",
        "isVisible": true,
        "left": "90dp",
        "skin": "sknlblValue",
        "text": "04/24/2016 15:13",
        "top": "60%",
        "width": kony.flex.USE_PREFFERED_SIZE
    }, {
        "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
        "padding": [0, 0, 0, 0],
        "paddingInPixel": false
    }, {
        "textCopyable": false,
        "wrapping": constants.WIDGET_TEXT_WORD_WRAP
    });
    var lblStartTImeValue = new kony.ui.Label({
        "id": "lblStartTImeValue",
        "isVisible": true,
        "left": 90,
        "skin": "sknlblValue",
        "text": "04/24/2016 14:50",
        "top": "25%",
        "width": kony.flex.USE_PREFFERED_SIZE
    }, {
        "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
        "padding": [0, 0, 0, 0],
        "paddingInPixel": false
    }, {
        "textCopyable": false,
        "wrapping": constants.WIDGET_TEXT_WORD_WRAP
    });
    var lblEndTime = new kony.ui.Label({
        "id": "lblEndTime",
        "isVisible": true,
        "left": "5%",
        "skin": "sknLabel",
        "text": "End Time:",
        "top": "60%",
        "width": kony.flex.USE_PREFFERED_SIZE,
        "zIndex": 1
    }, {
        "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
        "padding": [0, 0, 0, 0],
        "paddingInPixel": false
    }, {
        "textCopyable": false,
        "wrapping": constants.WIDGET_TEXT_WORD_WRAP
    });
    var btnEndTrip = new kony.ui.Button({
        "focusSkin": "CopysknBtnFocus0cc11389599ca47",
        "height": "30%",
        "id": "btnEndTrip",
        "isVisible": true,
        "onClick": AS_Button_0566ea4431554e99996cd3b99ba28534,
        "right": "3%",
        "skin": "CopysknBtnFF01eaec5e1d4334b",
        "text": "End Trip",
        "top": "20%",
        "width": "100dp",
        "zIndex": 1
    }, {
        "contentAlignment": constants.CONTENT_ALIGN_CENTER,
        "displayText": true,
        "padding": [0, 0, 0, 0],
        "paddingInPixel": false
    }, {
        "showProgressIndicator": true
    });
    var cameraPic = new kony.ui.Camera({
        "focusSkin": "CopyslCamera038968f54a8d54d",
        "height": "30%",
        "id": "cameraPic",
        "isVisible": true,
        "onCapture": AS_Camera_c175b33cea4144b181141e233d502ae3,
        "right": "3%",
        "skin": "CopyslCamera0928b79d7b6ee40",
        "text": "Report Issue",
        "top": "55%",
        "width": "100dp",
        "zIndex": 1
    }, {
        "contentAlignment": constants.CONTENT_ALIGN_CENTER,
        "padding": [0, 0, 0, 0],
        "paddingInPixel": false
    }, {
        "accessMode": constants.CAMERA_IMAGE_ACCESS_MODE_PUBLIC,
        "enableOverlay": false,
        "nativeUserInterface": true
    });
    FlexContainer08d2f4c72bc1640.add(
    lblStartTime, lblEndTImeValue, lblStartTImeValue, lblEndTime, btnEndTrip, cameraPic);
    var imgMap = new kony.ui.Image2({
        "height": "65%",
        "id": "imgMap",
        "isVisible": true,
        "left": "0dp",
        "skin": "slImage",
        "src": "routemapcopy.png",
        "top": "15%",
        "width": "100%",
        "zIndex": 1
    }, {
        "imageScaleMode": constants.IMAGE_SCALE_MODE_FIT_TO_DIMENSIONS,
        "padding": [0, 0, 0, 0],
        "paddingInPixel": false
    }, {});
    var flxOutput = new kony.ui.FlexContainer({
        "autogrowMode": kony.flex.AUTOGROW_NONE,
        "clipBounds": true,
        "height": "15%",
        "id": "flxOutput",
        "isVisible": true,
        "layoutType": kony.flex.FREE_FORM,
        "left": "0dp",
        "skin": "slFbox",
        "top": "82%",
        "width": "100%",
        "zIndex": 1
    }, {}, {});
    flxOutput.setDefaultUnit(kony.flex.DP);
    var CopyFlexContainer0e760f5f3cb8745 = new kony.ui.FlexContainer({
        "autogrowMode": kony.flex.AUTOGROW_NONE,
        "bottom": "2%",
        "clipBounds": true,
        "focusSkin": "CopyBGFFFFFF0323526f32f6f47",
        "height": "80%",
        "id": "CopyFlexContainer0e760f5f3cb8745",
        "isVisible": true,
        "layoutType": kony.flex.FREE_FORM,
        "left": "52.66%",
        "skin": "CopyBGFFFFFF031b24f5ea0e748",
        "width": "40%"
    }, {}, {});
    CopyFlexContainer0e760f5f3cb8745.setDefaultUnit(kony.flex.DP);
    var CopyLabel00b07ff6ea57741 = new kony.ui.Label({
        "centerX": "50%",
        "id": "CopyLabel00b07ff6ea57741",
        "isVisible": true,
        "skin": "Copysknlbl0b5e7205a2e004b",
        "text": "#Bumps",
        "top": "5%",
        "width": "90%"
    }, {
        "contentAlignment": constants.CONTENT_ALIGN_CENTER,
        "padding": [0, 0, 0, 0],
        "paddingInPixel": false
    }, {
        "textCopyable": false,
        "wrapping": constants.WIDGET_TEXT_WORD_WRAP
    });
    var lblBumpsCount = new kony.ui.Label({
        "centerX": "50%",
        "centerY": "60%",
        "id": "lblBumpsCount",
        "isVisible": true,
        "skin": "CopysknlblCN070a408eaf7ae41",
        "text": "89",
        "width": kony.flex.USE_PREFFERED_SIZE,
        "zIndex": 1
    }, {
        "contentAlignment": constants.CONTENT_ALIGN_CENTER,
        "padding": [0, 0, 0, 0],
        "paddingInPixel": false
    }, {
        "textCopyable": false,
        "wrapping": constants.WIDGET_TEXT_WORD_WRAP
    });
    CopyFlexContainer0e760f5f3cb8745.add(
    CopyLabel00b07ff6ea57741, lblBumpsCount);
    var flxQuality = new kony.ui.FlexContainer({
        "autogrowMode": kony.flex.AUTOGROW_NONE,
        "bottom": "2%",
        "clipBounds": true,
        "focusSkin": "CopyBGFFFFFF0be3721d241cb45",
        "height": "80%",
        "id": "flxQuality",
        "isVisible": true,
        "layoutType": kony.flex.FREE_FORM,
        "left": "6.30%",
        "skin": "CopyBGFFFFFF0f5b725090f2148",
        "width": "40%",
        "zIndex": 30
    }, {}, {});
    flxQuality.setDefaultUnit(kony.flex.DP);
    var Label03f1d747e92b743 = new kony.ui.Label({
        "centerX": "50%",
        "id": "Label03f1d747e92b743",
        "isVisible": true,
        "skin": "Copysknlbl0d30bd854fdea42",
        "text": "Quality",
        "top": "5%",
        "width": kony.flex.USE_PREFFERED_SIZE
    }, {
        "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
        "padding": [0, 0, 0, 0],
        "paddingInPixel": false
    }, {
        "textCopyable": false,
        "wrapping": constants.WIDGET_TEXT_WORD_WRAP
    });
    var Label080cac56f82a24b = new kony.ui.Label({
        "centerX": "50%",
        "centerY": "60%",
        "id": "Label080cac56f82a24b",
        "isVisible": true,
        "skin": "CopysknlblCN015f60169da104c",
        "text": "3/10",
        "width": kony.flex.USE_PREFFERED_SIZE,
        "zIndex": 1
    }, {
        "contentAlignment": constants.CONTENT_ALIGN_CENTER,
        "padding": [0, 0, 0, 0],
        "paddingInPixel": false
    }, {
        "textCopyable": false,
        "wrapping": constants.WIDGET_TEXT_WORD_WRAP
    });
    flxQuality.add(
    Label03f1d747e92b743, Label080cac56f82a24b);
    flxOutput.add(
    CopyFlexContainer0e760f5f3cb8745, flxQuality);
    flxOuter.add(
    FlexContainer08d2f4c72bc1640, imgMap, flxOutput);
    var FlexContainer0af4ba12e07cb44 = new kony.ui.FlexContainer({
        "autogrowMode": kony.flex.AUTOGROW_NONE,
        "clipBounds": true,
        "height": "8%",
        "id": "FlexContainer0af4ba12e07cb44",
        "isVisible": true,
        "layoutType": kony.flex.FREE_FORM,
        "left": "0",
        "skin": "CopyflxBGGreen08723e3e9fec344",
        "top": "0%",
        "width": "100%"
    }, {}, {});
    FlexContainer0af4ba12e07cb44.setDefaultUnit(kony.flex.DP);
    var lblTitle = new kony.ui.Label({
        "centerX": "48%",
        "centerY": "50%",
        "id": "lblTitle",
        "isVisible": true,
        "skin": "CopyslLabel0acaf0be04c9c4b",
        "text": "On Trip",
        "width": kony.flex.USE_PREFFERED_SIZE
    }, {
        "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
        "padding": [0, 0, 0, 0],
        "paddingInPixel": false
    }, {
        "textCopyable": false,
        "wrapping": constants.WIDGET_TEXT_WORD_WRAP
    });
    var Image0cc7265d9637545 = new kony.ui.Image2({
        "centerY": "50%",
        "height": "90%",
        "id": "Image0cc7265d9637545",
        "isVisible": true,
        "left": "0%",
        "onTouchEnd": AS_Image_d7498497efad40809382649a907c9ed3,
        "skin": "slImage",
        "src": "backwhite.png",
        "top": "12dp",
        "width": "12%",
        "zIndex": 1
    }, {
        "imageScaleMode": constants.IMAGE_SCALE_MODE_MAINTAIN_ASPECT_RATIO,
        "padding": [0, 0, 0, 0],
        "paddingInPixel": false
    }, {});
    FlexContainer0af4ba12e07cb44.add(
    lblTitle, Image0cc7265d9637545);
    frmStartTrip.add(
    flxOuter, FlexContainer0af4ba12e07cb44);
};

function frmStartTripGlobals() {
    frmStartTrip = new kony.ui.Form2({
        "addWidgets": addWidgetsfrmStartTrip,
        "enabledForIdleTimeout": false,
        "id": "frmStartTrip",
        "layoutType": kony.flex.FREE_FORM,
        "needAppMenu": false,
        "skin": "CopyslForm0b02761fac20f49"
    }, {
        "displayOrientation": constants.FORM_DISPLAY_ORIENTATION_PORTRAIT,
        "layoutType": kony.flex.FREE_FORM,
        "padding": [0, 0, 0, 0],
        "paddingInPixel": false
    }, {
        "configureExtendBottom": false,
        "configureExtendTop": false,
        "configureStatusBarStyle": false,
        "footerOverlap": false,
        "formTransparencyDuringPostShow": "100",
        "headerOverlap": false,
        "inputAccessoryViewType": constants.FORM_INPUTACCESSORYVIEW_CANCEL,
        "needsIndicatorDuringPostShow": false,
        "retainScrollPosition": false,
        "titleBar": false,
        "titleBarSkin": "slTitleBar"
    });
};