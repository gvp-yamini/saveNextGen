function AS_FlexContainer_e66597f3c32f442c98372d5aa2b5ca19(eventobject, x, y) {
    onClickHamburgerMenuOriginal(kony.application.getCurrentForm());
    frmIssues.show();
}