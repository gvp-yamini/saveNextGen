function AS_FlexContainer_982c447706ea47b591582359020e3c7c(eventobject, x, y) {
    onClickHamburgerMenuOriginal(kony.application.getCurrentForm());
    frmDashboard.show();
}