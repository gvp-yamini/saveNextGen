function AS_FlexContainer_dcfc353f260d47fc88e87e3a4a33d342(eventobject, x, y) {
    onClickHamburgerMenuOriginal(kony.application.getCurrentForm());
    frmContractors.show();
}