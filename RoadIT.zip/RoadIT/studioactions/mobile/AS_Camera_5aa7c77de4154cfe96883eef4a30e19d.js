function AS_Camera_5aa7c77de4154cfe96883eef4a30e19d(eventobject) {
    isFromST = false;
    frmIssue.show();
    frmIssue.ImgCaptured.rawBytes = frmDashboard.cameraPic.rawBytes;
    frmIssue.btnStartTrip.setVisibility(true);
    frmIssue.TextArea08ea20b91246d44.setEnabled(true);
}