function AS_Button_0566ea4431554e99996cd3b99ba28534(eventobject) {
    frmStartTrip.lblEndTImeValue.setVisibility(true);
    frmStartTrip.flxQuality.setVisibility(true);
    frmStartTrip.btnEndTrip.setVisibility(false);
    kony.accelerometer.unregisterAccelerationEvents(["shake"]);
    shakeCount = 0;
}