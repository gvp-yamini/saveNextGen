function AS_Switch_22af811982ee498bad506ed02582910b(eventobject) {
    if (frmDashboard.Switch0c15b97a05a7c4c.selectedIndex === 0) alert("Sure! Data will not be captured outside your favourite zone");
}