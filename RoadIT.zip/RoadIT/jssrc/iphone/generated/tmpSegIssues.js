function initializetmpSegIssues() {
    flxSegOuter = new kony.ui.FlexContainer({
        "autogrowMode": kony.flex.AUTOGROW_NONE,
        "clipBounds": true,
        "height": "85dp",
        "id": "flxSegOuter",
        "isVisible": true,
        "layoutType": kony.flex.FREE_FORM,
        "skin": "CopyslFbox0fbb4d0c3093343"
    }, {}, {});
    flxSegOuter.setDefaultUnit(kony.flex.DP);
    var lblDateValue = new kony.ui.Label({
        "id": "lblDateValue",
        "isVisible": true,
        "left": "5%",
        "skin": "sknlblValue",
        "text": "22nd May,2016",
        "top": "10dp",
        "width": "30%"
    }, {
        "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
        "padding": [0, 0, 0, 0],
        "paddingInPixel": false
    }, {
        "textCopyable": false,
        "wrapping": constants.WIDGET_TEXT_WORD_WRAP
    });
    var lblTo = new kony.ui.Label({
        "id": "lblTo",
        "isVisible": true,
        "left": "5%",
        "skin": "sknLabel",
        "text": "Issue at Balanagar",
        "top": "30dp",
        "width": kony.flex.USE_PREFFERED_SIZE
    }, {
        "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
        "padding": [0, 0, 0, 0],
        "paddingInPixel": false
    }, {
        "textCopyable": false,
        "wrapping": constants.WIDGET_TEXT_WORD_WRAP
    });
    var lblFromValue = new kony.ui.Label({
        "id": "lblFromValue",
        "isVisible": true,
        "left": "5%",
        "skin": "sknlblValue",
        "text": "A tree has fallen on road fjfkl' fjdklfj jakjdsf fsdfsd fd s   d fd df df  klfjsdkljkl jklsdjfkl....",
        "top": "50dp",
        "width": "90%"
    }, {
        "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
        "padding": [0, 0, 0, 0],
        "paddingInPixel": false
    }, {
        "textCopyable": false,
        "wrapping": constants.WIDGET_TEXT_WORD_WRAP
    });
    var lblTitle = new kony.ui.Label({
        "id": "lblTitle",
        "isVisible": true,
        "left": "75%",
        "skin": "CopysknlblCN09777f16347024d",
        "text": "Closed",
        "top": "15%",
        "width": kony.flex.USE_PREFFERED_SIZE
    }, {
        "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
        "padding": [0, 0, 0, 0],
        "paddingInPixel": false
    }, {
        "textCopyable": false,
        "wrapping": constants.WIDGET_TEXT_WORD_WRAP
    });
    flxSegOuter.add(
    lblDateValue, lblTo, lblFromValue, lblTitle);
}