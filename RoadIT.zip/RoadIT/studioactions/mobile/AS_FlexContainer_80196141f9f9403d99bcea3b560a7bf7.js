function AS_FlexContainer_80196141f9f9403d99bcea3b560a7bf7(eventobject, x, y) {
    onClickHamburgerMenuOriginal(kony.application.getCurrentForm());
    frmTripList.show();
}