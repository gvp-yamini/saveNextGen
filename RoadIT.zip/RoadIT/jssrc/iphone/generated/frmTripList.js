function addWidgetsfrmTripList() {
    frmTripList.setDefaultUnit(kony.flex.DP);
    var flxOuter = new kony.ui.FlexContainer({
        "autogrowMode": kony.flex.AUTOGROW_NONE,
        "clipBounds": true,
        "height": "100%",
        "id": "flxOuter",
        "isVisible": true,
        "layoutType": kony.flex.FREE_FORM,
        "left": "0dp",
        "skin": "slFbox",
        "top": "0dp",
        "width": "100%",
        "zIndex": 1
    }, {}, {});
    flxOuter.setDefaultUnit(kony.flex.DP);
    var CopyFlexContainer09aa48a1d28104e = new kony.ui.FlexContainer({
        "autogrowMode": kony.flex.AUTOGROW_NONE,
        "clipBounds": true,
        "height": "8%",
        "id": "CopyFlexContainer09aa48a1d28104e",
        "isVisible": true,
        "layoutType": kony.flex.FREE_FORM,
        "left": "0",
        "skin": "CopyflxBGGreen08723e3e9fec344",
        "top": "0",
        "width": "100%"
    }, {}, {});
    CopyFlexContainer09aa48a1d28104e.setDefaultUnit(kony.flex.DP);
    var CopylblTitle0110bff5cb1ed46 = new kony.ui.Label({
        "centerX": "48%",
        "centerY": "50%",
        "id": "CopylblTitle0110bff5cb1ed46",
        "isVisible": true,
        "skin": "CopyslLabel0acaf0be04c9c4b",
        "text": "Trip List",
        "width": kony.flex.USE_PREFFERED_SIZE
    }, {
        "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
        "padding": [0, 0, 0, 0],
        "paddingInPixel": false
    }, {
        "textCopyable": false,
        "wrapping": constants.WIDGET_TEXT_WORD_WRAP
    });
    var CopyImage0005bde45b0f54c = new kony.ui.Image2({
        "centerY": "50%",
        "height": "90%",
        "id": "CopyImage0005bde45b0f54c",
        "isVisible": true,
        "left": "3%",
        "onTouchEnd": AS_Image_ddef13c5da914445bf14544f8789b59a,
        "skin": "slImage",
        "src": "menuwhite.png",
        "top": "8dp",
        "width": "12%",
        "zIndex": 1
    }, {
        "imageScaleMode": constants.IMAGE_SCALE_MODE_MAINTAIN_ASPECT_RATIO,
        "padding": [0, 0, 0, 0],
        "paddingInPixel": false
    }, {});
    CopyFlexContainer09aa48a1d28104e.add(
    CopylblTitle0110bff5cb1ed46, CopyImage0005bde45b0f54c);
    var flxBody = new kony.ui.FlexContainer({
        "autogrowMode": kony.flex.AUTOGROW_NONE,
        "clipBounds": true,
        "height": "92%",
        "id": "flxBody",
        "isVisible": true,
        "layoutType": kony.flex.FREE_FORM,
        "left": "0dp",
        "skin": "sknflxnoborder",
        "top": "8%",
        "width": "100%"
    }, {}, {});
    flxBody.setDefaultUnit(kony.flex.DP);
    var CopySegment0096de478f8454a = new kony.ui.SegmentedUI2({
        "autogrowMode": kony.flex.AUTOGROW_NONE,
        "data": [
            [{
                "Label05d038c6e204a48": "Today"
            }, [{
                "Button0a343b7d7f58742": "Contribute",
                "CopylblFromValue0cfcbd4dda2244e": "47",
                "CopylblQuality0237aac80b76646": "#Bumps: ",
                "lblDateValue": "28 May,2016",
                "lblFrom": "From: ",
                "lblFromValue": "Lakdi ka Pool",
                "lblQualityValue": "3/10",
                "lblTo": "To: ",
                "lblToValue": "Ameerpet"
            }, {
                "Button0a343b7d7f58742": "Contribute",
                "CopylblFromValue0cfcbd4dda2244e": "29",
                "CopylblQuality0237aac80b76646": "#Bumps: ",
                "lblDateValue": "28 May,2016",
                "lblFrom": "From: ",
                "lblFromValue": "Panjagutta",
                "lblQualityValue": "5/10",
                "lblTo": "To: ",
                "lblToValue": "Hi-Tech City"
            }]],
            [{
                "Label05d038c6e204a48": "This Week"
            }, [{
                "Button0a343b7d7f58742": "Contribute",
                "CopylblFromValue0cfcbd4dda2244e": "37",
                "CopylblQuality0237aac80b76646": "#Bumps: ",
                "lblDateValue": "27 May,2016",
                "lblFrom": "From: ",
                "lblFromValue": "Kukatpally",
                "lblQualityValue": "4/10",
                "lblTo": "To: ",
                "lblToValue": "Ameerpet"
            }, {
                "Button0a343b7d7f58742": "Contribute",
                "CopylblFromValue0cfcbd4dda2244e": "23",
                "CopylblQuality0237aac80b76646": "#Bumps: ",
                "lblDateValue": "27 May,2016",
                "lblFrom": "From: ",
                "lblFromValue": "Miyapur",
                "lblQualityValue": "6/10",
                "lblTo": "To: ",
                "lblToValue": "Nizampet"
            }, {
                "Button0a343b7d7f58742": "Contribute",
                "CopylblFromValue0cfcbd4dda2244e": "16",
                "CopylblQuality0237aac80b76646": "#Bumps: ",
                "lblDateValue": "27 May,2016",
                "lblFrom": "From: ",
                "lblFromValue": "Patny Center",
                "lblQualityValue": "7/10",
                "lblTo": "To: ",
                "lblToValue": "Madapur"
            }]],
            [{
                "Label05d038c6e204a48": "This Month"
            }, [{
                "Button0a343b7d7f58742": "Contribute",
                "CopylblFromValue0cfcbd4dda2244e": "23",
                "CopylblQuality0237aac80b76646": "#Bumps",
                "lblDateValue": "22nd May,2016",
                "lblFrom": "From:",
                "lblFromValue": "Lakdi ka pool",
                "lblQualityValue": "6/10",
                "lblTo": "To:",
                "lblToValue": "Ameerpet"
            }, {
                "Button0a343b7d7f58742": "Contribute",
                "CopylblFromValue0cfcbd4dda2244e": "45",
                "CopylblQuality0237aac80b76646": "#Bumps",
                "lblDateValue": "22nd May,2016",
                "lblFrom": "From:",
                "lblFromValue": "Lakdi ka pool",
                "lblQualityValue": "3/10",
                "lblTo": "To:",
                "lblToValue": "Ameerpet"
            }, {
                "Button0a343b7d7f58742": "Contribute",
                "CopylblFromValue0cfcbd4dda2244e": "9",
                "CopylblQuality0237aac80b76646": "#Bumps",
                "lblDateValue": "22nd May,2016",
                "lblFrom": "From:",
                "lblFromValue": "Lakdi ka pool",
                "lblQualityValue": "8/10",
                "lblTo": "To:",
                "lblToValue": "Ameerpet"
            }]]
        ],
        "groupCells": false,
        "height": "100%",
        "id": "CopySegment0096de478f8454a",
        "isVisible": true,
        "left": "0dp",
        "needPageIndicator": true,
        "pageOffDotImage": "pageOffDot.png",
        "pageOnDotImage": "pageOnDot.png",
        "retainSelection": false,
        "rowFocusSkin": "seg2Focus",
        "rowSkin": "seg2Normal",
        "rowTemplate": FlexContainer0b52f60c4cc6949,
        "scrollingEvents": {},
        "sectionHeaderSkin": "sliPhoneSegmentHeader",
        "sectionHeaderTemplate": FlexContainer01ddd6bbb88364b,
        "selectionBehavior": constants.SEGUI_DEFAULT_BEHAVIOR,
        "separatorColor": "64646432",
        "separatorRequired": true,
        "separatorThickness": 1,
        "showScrollbars": false,
        "top": "0dp",
        "viewType": constants.SEGUI_VIEW_TYPE_TABLEVIEW,
        "widgetDataMap": {
            "Button0a343b7d7f58742": "Button0a343b7d7f58742",
            "CopylblFromValue0cfcbd4dda2244e": "CopylblFromValue0cfcbd4dda2244e",
            "CopylblQuality0237aac80b76646": "CopylblQuality0237aac80b76646",
            "FlexContainer01ddd6bbb88364b": "FlexContainer01ddd6bbb88364b",
            "FlexContainer0b52f60c4cc6949": "FlexContainer0b52f60c4cc6949",
            "Label05d038c6e204a48": "Label05d038c6e204a48",
            "lblDateValue": "lblDateValue",
            "lblFrom": "lblFrom",
            "lblFromValue": "lblFromValue",
            "lblQualityValue": "lblQualityValue",
            "lblTo": "lblTo",
            "lblToValue": "lblToValue"
        },
        "width": "100%"
    }, {
        "padding": [0, 0, 0, 0],
        "paddingInPixel": false
    }, {
        "bounces": true,
        "editStyle": constants.SEGUI_EDITING_STYLE_NONE,
        "enableDictionary": false,
        "indicator": constants.SEGUI_NONE,
        "progressIndicatorColor": constants.PROGRESS_INDICATOR_COLOR_WHITE,
        "showProgressIndicator": true
    });
    var FlexContainer004ef44a0986e43 = new kony.ui.FlexContainer({
        "autogrowMode": kony.flex.AUTOGROW_NONE,
        "clipBounds": true,
        "height": "100%",
        "id": "FlexContainer004ef44a0986e43",
        "isVisible": false,
        "layoutType": kony.flex.FREE_FORM,
        "left": "0dp",
        "skin": "CopyslFbox0bef81d7f4e0740",
        "top": "0dp",
        "width": "100%",
        "zIndex": 5
    }, {}, {});
    FlexContainer004ef44a0986e43.setDefaultUnit(kony.flex.DP);
    var FlexContainer0d31798c7254c4e = new kony.ui.FlexContainer({
        "autogrowMode": kony.flex.AUTOGROW_NONE,
        "centerX": "50%",
        "centerY": "50%",
        "clipBounds": true,
        "height": "25%",
        "id": "FlexContainer0d31798c7254c4e",
        "isVisible": true,
        "layoutType": kony.flex.FLOW_VERTICAL,
        "left": "29dp",
        "skin": "CopyflexHead09fba77d913c341",
        "top": "174dp",
        "width": "80%"
    }, {}, {});
    FlexContainer0d31798c7254c4e.setDefaultUnit(kony.flex.DP);
    var CopyflxLine04775a4f60e7f4c = new kony.ui.FlexContainer({
        "autogrowMode": kony.flex.AUTOGROW_NONE,
        "centerX": "50%",
        "clipBounds": true,
        "height": "1px",
        "id": "CopyflxLine04775a4f60e7f4c",
        "isVisible": true,
        "layoutType": kony.flex.FREE_FORM,
        "left": "0dp",
        "skin": "Copysknline083948e0a78664e",
        "top": "20%",
        "width": "100%",
        "zIndex": 1
    }, {}, {});
    CopyflxLine04775a4f60e7f4c.setDefaultUnit(kony.flex.DP);
    CopyflxLine04775a4f60e7f4c.add();
    var Label03edfae75a9e748 = new kony.ui.Label({
        "centerX": "50%",
        "height": "30%",
        "id": "Label03edfae75a9e748",
        "isVisible": true,
        "skin": "CopyslLabel0860567b057e14a",
        "text": "Money",
        "top": "0%",
        "width": "100%"
    }, {
        "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
        "padding": [37, 0, 0, 0],
        "paddingInPixel": false
    }, {
        "textCopyable": false,
        "wrapping": constants.WIDGET_TEXT_WORD_WRAP
    });
    var CopyflxLine089abc477fc1a4f = new kony.ui.FlexContainer({
        "autogrowMode": kony.flex.AUTOGROW_NONE,
        "centerX": "50%",
        "clipBounds": true,
        "height": "1px",
        "id": "CopyflxLine089abc477fc1a4f",
        "isVisible": true,
        "layoutType": kony.flex.FREE_FORM,
        "left": "0dp",
        "skin": "Copysknline083948e0a78664e",
        "top": "0%",
        "width": "100%",
        "zIndex": 1
    }, {}, {});
    CopyflxLine089abc477fc1a4f.setDefaultUnit(kony.flex.DP);
    CopyflxLine089abc477fc1a4f.add();
    var CopyLabel00903574e4d8743 = new kony.ui.Label({
        "centerX": "50%",
        "height": "30%",
        "id": "CopyLabel00903574e4d8743",
        "isVisible": true,
        "skin": "CopyslLabel0860567b057e14a",
        "text": "Effort",
        "top": "0%",
        "width": "100%"
    }, {
        "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
        "padding": [37, 0, 0, 0],
        "paddingInPixel": false
    }, {
        "textCopyable": false,
        "wrapping": constants.WIDGET_TEXT_WORD_WRAP
    });
    var CopyflxLine0f3a153fed1b246 = new kony.ui.FlexContainer({
        "autogrowMode": kony.flex.AUTOGROW_NONE,
        "centerX": "50%",
        "clipBounds": true,
        "height": "1px",
        "id": "CopyflxLine0f3a153fed1b246",
        "isVisible": true,
        "layoutType": kony.flex.FREE_FORM,
        "left": "0dp",
        "skin": "Copysknline083948e0a78664e",
        "top": "0%",
        "width": "100%",
        "zIndex": 1
    }, {}, {});
    CopyflxLine0f3a153fed1b246.setDefaultUnit(kony.flex.DP);
    CopyflxLine0f3a153fed1b246.add();
    FlexContainer0d31798c7254c4e.add(
    CopyflxLine04775a4f60e7f4c, Label03edfae75a9e748, CopyflxLine089abc477fc1a4f, CopyLabel00903574e4d8743, CopyflxLine0f3a153fed1b246);
    FlexContainer004ef44a0986e43.add(
    FlexContainer0d31798c7254c4e);
    flxBody.add(
    CopySegment0096de478f8454a, FlexContainer004ef44a0986e43);
    flxOuter.add(
    CopyFlexContainer09aa48a1d28104e, flxBody);
    var flxMenuMain = new kony.ui.FlexContainer({
        "autogrowMode": kony.flex.AUTOGROW_NONE,
        "clipBounds": true,
        "height": "92%",
        "id": "flxMenuMain",
        "isVisible": true,
        "layoutType": kony.flex.FLOW_VERTICAL,
        "right": "100%",
        "skin": "slFbox",
        "top": "8%",
        "width": "65%",
        "zIndex": 1
    }, {}, {});
    flxMenuMain.setDefaultUnit(kony.flex.DP);
    var flxLine = new kony.ui.FlexContainer({
        "autogrowMode": kony.flex.AUTOGROW_NONE,
        "centerX": "50%",
        "clipBounds": true,
        "height": "1px",
        "id": "flxLine",
        "isVisible": true,
        "layoutType": kony.flex.FREE_FORM,
        "left": "80dp",
        "skin": "sknline",
        "top": "0dp",
        "width": "100%",
        "zIndex": 1
    }, {}, {});
    flxLine.setDefaultUnit(kony.flex.DP);
    flxLine.add();
    var flxDashboard = new kony.ui.FlexContainer({
        "autogrowMode": kony.flex.AUTOGROW_NONE,
        "clipBounds": true,
        "height": "10%",
        "id": "flxDashboard",
        "isVisible": true,
        "layoutType": kony.flex.FREE_FORM,
        "left": "0dp",
        "onTouchEnd": AS_FlexContainer_982c447706ea47b591582359020e3c7c,
        "skin": "slFbox",
        "top": 0,
        "width": "100%"
    }, {}, {});
    flxDashboard.setDefaultUnit(kony.flex.DP);
    var Label04125fb89a62f40 = new kony.ui.Label({
        "centerY": "50%",
        "id": "Label04125fb89a62f40",
        "isVisible": true,
        "left": "10%",
        "skin": "LBLMOBCB28FFFFFF",
        "text": "Dashboard",
        "width": kony.flex.USE_PREFFERED_SIZE
    }, {
        "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
        "padding": [0, 0, 0, 0],
        "paddingInPixel": false
    }, {
        "textCopyable": false,
        "wrapping": constants.WIDGET_TEXT_WORD_WRAP
    });
    var CopyflxLine0fd5bfc8da0be47 = new kony.ui.FlexContainer({
        "autogrowMode": kony.flex.AUTOGROW_NONE,
        "bottom": "0dp",
        "centerX": "50%",
        "clipBounds": true,
        "height": "1px",
        "id": "CopyflxLine0fd5bfc8da0be47",
        "isVisible": true,
        "layoutType": kony.flex.FREE_FORM,
        "skin": "sknline",
        "width": "90%",
        "zIndex": 1
    }, {}, {});
    CopyflxLine0fd5bfc8da0be47.setDefaultUnit(kony.flex.DP);
    CopyflxLine0fd5bfc8da0be47.add();
    flxDashboard.add(
    Label04125fb89a62f40, CopyflxLine0fd5bfc8da0be47);
    var flxTrips = new kony.ui.FlexContainer({
        "autogrowMode": kony.flex.AUTOGROW_NONE,
        "clipBounds": true,
        "height": "10%",
        "id": "flxTrips",
        "isVisible": true,
        "layoutType": kony.flex.FREE_FORM,
        "left": "0dp",
        "onTouchEnd": AS_FlexContainer_f6917a6b5a5742e8b7bb058483bfbbd4,
        "skin": "slFbox",
        "top": "0dp",
        "width": "100%"
    }, {}, {});
    flxTrips.setDefaultUnit(kony.flex.DP);
    var CopyLabel0281cc3aac14d49 = new kony.ui.Label({
        "centerY": "50%",
        "id": "CopyLabel0281cc3aac14d49",
        "isVisible": true,
        "left": "10%",
        "skin": "LBLMOBCB28FFFFFF",
        "text": "Trips",
        "width": kony.flex.USE_PREFFERED_SIZE
    }, {
        "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
        "padding": [0, 0, 0, 0],
        "paddingInPixel": false
    }, {
        "textCopyable": false,
        "wrapping": constants.WIDGET_TEXT_WORD_WRAP
    });
    var CopyflxLine0932af4004df445 = new kony.ui.FlexContainer({
        "autogrowMode": kony.flex.AUTOGROW_NONE,
        "bottom": "0px",
        "centerX": "50%",
        "clipBounds": true,
        "height": "1px",
        "id": "CopyflxLine0932af4004df445",
        "isVisible": true,
        "layoutType": kony.flex.FREE_FORM,
        "skin": "sknline",
        "width": "90%",
        "zIndex": 1
    }, {}, {});
    CopyflxLine0932af4004df445.setDefaultUnit(kony.flex.DP);
    CopyflxLine0932af4004df445.add();
    flxTrips.add(
    CopyLabel0281cc3aac14d49, CopyflxLine0932af4004df445);
    var flxIssues = new kony.ui.FlexContainer({
        "autogrowMode": kony.flex.AUTOGROW_NONE,
        "clipBounds": true,
        "height": "10%",
        "id": "flxIssues",
        "isVisible": true,
        "layoutType": kony.flex.FREE_FORM,
        "left": "0dp",
        "onTouchEnd": AS_FlexContainer_e66597f3c32f442c98372d5aa2b5ca19,
        "skin": "slFbox",
        "top": "0dp",
        "width": "100%"
    }, {}, {});
    flxIssues.setDefaultUnit(kony.flex.DP);
    var CopyLabel0202755656a1046 = new kony.ui.Label({
        "centerY": "50%",
        "id": "CopyLabel0202755656a1046",
        "isVisible": true,
        "left": "10%",
        "skin": "LBLMOBCB28FFFFFF",
        "text": "Issues",
        "width": kony.flex.USE_PREFFERED_SIZE
    }, {
        "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
        "padding": [0, 0, 0, 0],
        "paddingInPixel": false
    }, {
        "textCopyable": false,
        "wrapping": constants.WIDGET_TEXT_WORD_WRAP
    });
    var CopyflxLine0b414cfb2ffdf49 = new kony.ui.FlexContainer({
        "autogrowMode": kony.flex.AUTOGROW_NONE,
        "bottom": "0dp",
        "centerX": "50%",
        "clipBounds": true,
        "height": "1px",
        "id": "CopyflxLine0b414cfb2ffdf49",
        "isVisible": true,
        "layoutType": kony.flex.FREE_FORM,
        "skin": "sknline",
        "width": "90%",
        "zIndex": 1
    }, {}, {});
    CopyflxLine0b414cfb2ffdf49.setDefaultUnit(kony.flex.DP);
    CopyflxLine0b414cfb2ffdf49.add();
    flxIssues.add(
    CopyLabel0202755656a1046, CopyflxLine0b414cfb2ffdf49);
    var flxContractors = new kony.ui.FlexContainer({
        "autogrowMode": kony.flex.AUTOGROW_NONE,
        "clipBounds": true,
        "height": "10%",
        "id": "flxContractors",
        "isVisible": true,
        "layoutType": kony.flex.FREE_FORM,
        "left": "0dp",
        "onTouchEnd": AS_FlexContainer_8f8c90698d66480dad592dd0c1ca2b28,
        "skin": "slFbox",
        "top": "0dp",
        "width": "100%"
    }, {}, {});
    flxContractors.setDefaultUnit(kony.flex.DP);
    var CopyLabel03d0b0b7981944a = new kony.ui.Label({
        "centerY": "50%",
        "id": "CopyLabel03d0b0b7981944a",
        "isVisible": true,
        "left": "10%",
        "skin": "LBLMOBCB28FFFFFF",
        "text": "Contractors",
        "width": kony.flex.USE_PREFFERED_SIZE
    }, {
        "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
        "padding": [0, 0, 0, 0],
        "paddingInPixel": false
    }, {
        "textCopyable": false,
        "wrapping": constants.WIDGET_TEXT_WORD_WRAP
    });
    var CopyflxLine01e956f0002f44e = new kony.ui.FlexContainer({
        "autogrowMode": kony.flex.AUTOGROW_NONE,
        "bottom": "0dp",
        "centerX": "50%",
        "clipBounds": true,
        "height": "1px",
        "id": "CopyflxLine01e956f0002f44e",
        "isVisible": true,
        "layoutType": kony.flex.FREE_FORM,
        "skin": "sknline",
        "width": "90%",
        "zIndex": 1
    }, {}, {});
    CopyflxLine01e956f0002f44e.setDefaultUnit(kony.flex.DP);
    CopyflxLine01e956f0002f44e.add();
    flxContractors.add(
    CopyLabel03d0b0b7981944a, CopyflxLine01e956f0002f44e);
    var flxLogout = new kony.ui.FlexContainer({
        "autogrowMode": kony.flex.AUTOGROW_NONE,
        "clipBounds": true,
        "height": "10%",
        "id": "flxLogout",
        "isVisible": true,
        "layoutType": kony.flex.FREE_FORM,
        "left": "0dp",
        "onTouchEnd": AS_FlexContainer_dd1675a0675f43f8974bad9a7b6c3754,
        "skin": "slFbox",
        "top": "0dp",
        "width": "100%"
    }, {}, {});
    flxLogout.setDefaultUnit(kony.flex.DP);
    var CopyLabel0d0d31936215146 = new kony.ui.Label({
        "centerY": "50%",
        "id": "CopyLabel0d0d31936215146",
        "isVisible": true,
        "left": "10%",
        "skin": "LBLMOBCB28FFFFFF",
        "text": "Logout",
        "width": kony.flex.USE_PREFFERED_SIZE
    }, {
        "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
        "padding": [0, 0, 0, 0],
        "paddingInPixel": false
    }, {
        "textCopyable": false,
        "wrapping": constants.WIDGET_TEXT_WORD_WRAP
    });
    var CopyflxLine0c6f4c764071841 = new kony.ui.FlexContainer({
        "autogrowMode": kony.flex.AUTOGROW_NONE,
        "bottom": "0dp",
        "centerX": "50%",
        "clipBounds": true,
        "height": "1px",
        "id": "CopyflxLine0c6f4c764071841",
        "isVisible": true,
        "layoutType": kony.flex.FREE_FORM,
        "skin": "sknline",
        "width": "100%",
        "zIndex": 1
    }, {}, {});
    CopyflxLine0c6f4c764071841.setDefaultUnit(kony.flex.DP);
    CopyflxLine0c6f4c764071841.add();
    flxLogout.add(
    CopyLabel0d0d31936215146, CopyflxLine0c6f4c764071841);
    flxMenuMain.add(
    flxLine, flxDashboard, flxTrips, flxIssues, flxContractors, flxLogout);
    frmTripList.add(
    flxOuter, flxMenuMain);
};

function frmTripListGlobals() {
    frmTripList = new kony.ui.Form2({
        "addWidgets": addWidgetsfrmTripList,
        "enabledForIdleTimeout": false,
        "id": "frmTripList",
        "layoutType": kony.flex.FREE_FORM,
        "needAppMenu": false,
        "skin": "CopyslForm0a29b8f3dd0ee42"
    }, {
        "displayOrientation": constants.FORM_DISPLAY_ORIENTATION_PORTRAIT,
        "layoutType": kony.flex.FREE_FORM,
        "padding": [0, 0, 0, 0],
        "paddingInPixel": false
    }, {
        "configureExtendBottom": false,
        "configureExtendTop": false,
        "configureStatusBarStyle": false,
        "footerOverlap": false,
        "formTransparencyDuringPostShow": "100",
        "headerOverlap": false,
        "inputAccessoryViewType": constants.FORM_INPUTACCESSORYVIEW_CANCEL,
        "needsIndicatorDuringPostShow": false,
        "retainScrollPosition": false,
        "titleBar": false,
        "titleBarSkin": "slTitleBar"
    });
};