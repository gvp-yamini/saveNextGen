function addWidgetsfrmIssue() {
    frmIssue.setDefaultUnit(kony.flex.DP);
    var flxOuter = new kony.ui.FlexContainer({
        "autogrowMode": kony.flex.AUTOGROW_NONE,
        "clipBounds": true,
        "height": "100%",
        "id": "flxOuter",
        "isVisible": true,
        "layoutType": kony.flex.FREE_FORM,
        "left": "0dp",
        "skin": "sknflxnoborder",
        "top": "0dp",
        "width": "100%"
    }, {}, {});
    flxOuter.setDefaultUnit(kony.flex.DP);
    var FlexContainer0af4ba12e07cb44 = new kony.ui.FlexContainer({
        "autogrowMode": kony.flex.AUTOGROW_NONE,
        "clipBounds": true,
        "height": "8%",
        "id": "FlexContainer0af4ba12e07cb44",
        "isVisible": true,
        "layoutType": kony.flex.FREE_FORM,
        "left": "0",
        "skin": "CopyflxBGGreen08723e3e9fec344",
        "top": "0",
        "width": "100%"
    }, {}, {});
    FlexContainer0af4ba12e07cb44.setDefaultUnit(kony.flex.DP);
    var lblTitle = new kony.ui.Label({
        "centerX": "48%",
        "centerY": "50%",
        "id": "lblTitle",
        "isVisible": true,
        "skin": "CopyslLabel0acaf0be04c9c4b",
        "text": "Issue",
        "width": kony.flex.USE_PREFFERED_SIZE
    }, {
        "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
        "padding": [0, 0, 0, 0],
        "paddingInPixel": false
    }, {
        "textCopyable": false,
        "wrapping": constants.WIDGET_TEXT_WORD_WRAP
    });
    var Image0cc7265d9637545 = new kony.ui.Image2({
        "centerY": "50.23%",
        "height": "90%",
        "id": "Image0cc7265d9637545",
        "isVisible": true,
        "left": "0.00%",
        "onTouchEnd": AS_Image_874ab94c1c4f4a01b1f1def540e5152f,
        "skin": "slImage",
        "src": "backwhite.png",
        "top": "12dp",
        "width": "12%",
        "zIndex": 1
    }, {
        "imageScaleMode": constants.IMAGE_SCALE_MODE_MAINTAIN_ASPECT_RATIO,
        "padding": [0, 0, 0, 0],
        "paddingInPixel": false
    }, {});
    FlexContainer0af4ba12e07cb44.add(
    lblTitle, Image0cc7265d9637545);
    var FlexContainer048950eb44d0e40 = new kony.ui.FlexContainer({
        "autogrowMode": kony.flex.AUTOGROW_NONE,
        "clipBounds": true,
        "height": "92%",
        "id": "FlexContainer048950eb44d0e40",
        "isVisible": true,
        "layoutType": kony.flex.FLOW_VERTICAL,
        "left": "0dp",
        "skin": "slFbox",
        "top": "8%",
        "width": "100%",
        "zIndex": 1
    }, {}, {});
    FlexContainer048950eb44d0e40.setDefaultUnit(kony.flex.DP);
    var ImgCaptured = new kony.ui.Image2({
        "centerX": "50%",
        "height": "40%",
        "id": "ImgCaptured",
        "isVisible": true,
        "left": "5dp",
        "skin": "slImage",
        "src": "tree.png",
        "top": "10%",
        "width": "90%"
    }, {
        "imageScaleMode": constants.IMAGE_SCALE_MODE_FIT_TO_DIMENSIONS,
        "padding": [0, 0, 0, 0],
        "paddingInPixel": false
    }, {});
    var FlexContainer0ab97717f1fb641 = new kony.ui.FlexContainer({
        "autogrowMode": kony.flex.AUTOGROW_NONE,
        "clipBounds": true,
        "height": "50%",
        "id": "FlexContainer0ab97717f1fb641",
        "isVisible": true,
        "layoutType": kony.flex.FREE_FORM,
        "left": "0dp",
        "skin": "slFbox",
        "top": "0dp",
        "width": "100%",
        "zIndex": 1
    }, {}, {});
    FlexContainer0ab97717f1fb641.setDefaultUnit(kony.flex.DP);
    var Label0f3aa0e9180c64c = new kony.ui.Label({
        "id": "Label0f3aa0e9180c64c",
        "isVisible": true,
        "left": "5%",
        "skin": "sknlbl24cb5e5050",
        "text": "Description:",
        "top": "5%",
        "width": kony.flex.USE_PREFFERED_SIZE
    }, {
        "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
        "padding": [0, 0, 0, 0],
        "paddingInPixel": false
    }, {
        "textCopyable": false,
        "wrapping": constants.WIDGET_TEXT_WORD_WRAP
    });
    var TextArea08ea20b91246d44 = new kony.ui.TextArea2({
        "autoCapitalize": constants.TEXTAREA_AUTO_CAPITALIZE_NONE,
        "centerX": "50%",
        "height": "50%",
        "id": "TextArea08ea20b91246d44",
        "isVisible": true,
        "keyBoardStyle": constants.TEXTAREA_KEY_BOARD_STYLE_DEFAULT,
        "numberOfVisibleLines": 3,
        "placeholder": "Enter Description Here",
        "skin": "CopyslTextArea09306efd81b5140",
        "textInputMode": constants.TEXTAREA_INPUT_MODE_ANY,
        "top": "15%",
        "width": "90%",
        "zIndex": 1
    }, {
        "contentAlignment": constants.CONTENT_ALIGN_TOP_LEFT,
        "padding": [2, 2, 2, 2],
        "paddingInPixel": false
    }, {
        "autoCorrect": false,
        "keyboardActionLabel": constants.TEXTAREA_KEYBOARD_LABEL_DONE,
        "showCloseButton": true,
        "showProgressIndicator": false
    });
    var btnStartTrip = new kony.ui.Button({
        "centerX": "50.00%",
        "focusSkin": "sknBtnFocus",
        "height": "15%",
        "id": "btnStartTrip",
        "isVisible": true,
        "left": "5%",
        "onClick": AS_Button_065a51e2881a4a539f0ad8e1a85b732b,
        "skin": "sknBtnFF5D6E",
        "text": "Submit",
        "top": "75%",
        "width": "80%"
    }, {
        "contentAlignment": constants.CONTENT_ALIGN_CENTER,
        "displayText": true,
        "padding": [0, 0, 0, 0],
        "paddingInPixel": false
    }, {
        "showProgressIndicator": true
    });
    FlexContainer0ab97717f1fb641.add(
    Label0f3aa0e9180c64c, TextArea08ea20b91246d44, btnStartTrip);
    FlexContainer048950eb44d0e40.add(
    ImgCaptured, FlexContainer0ab97717f1fb641);
    flxOuter.add(
    FlexContainer0af4ba12e07cb44, FlexContainer048950eb44d0e40);
    frmIssue.add(
    flxOuter);
};

function frmIssueGlobals() {
    frmIssue = new kony.ui.Form2({
        "addWidgets": addWidgetsfrmIssue,
        "enabledForIdleTimeout": false,
        "id": "frmIssue",
        "layoutType": kony.flex.FREE_FORM,
        "needAppMenu": false,
        "skin": "CopyslForm0b02761fac20f49"
    }, {
        "displayOrientation": constants.FORM_DISPLAY_ORIENTATION_PORTRAIT,
        "layoutType": kony.flex.FREE_FORM,
        "padding": [0, 0, 0, 0],
        "paddingInPixel": false
    }, {
        "configureExtendBottom": false,
        "configureExtendTop": false,
        "configureStatusBarStyle": false,
        "footerOverlap": false,
        "formTransparencyDuringPostShow": "100",
        "headerOverlap": false,
        "inputAccessoryViewType": constants.FORM_INPUTACCESSORYVIEW_CANCEL,
        "needsIndicatorDuringPostShow": false,
        "retainScrollPosition": false,
        "titleBar": false,
        "titleBarSkin": "slTitleBar"
    });
};