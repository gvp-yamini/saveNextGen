function AS_Camera_c175b33cea4144b181141e233d502ae3(eventobject) {
    //isFromST=true;
    frmIssue.show();
    frmIssue.ImgCaptured.rawBytes = frmStartTrip.cameraPic.rawBytes;
    frmIssue.btnStartTrip.setVisibility(true);
    frmIssue.TextArea08ea20b91246d44.setEnabled(true);
}