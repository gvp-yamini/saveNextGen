function addWidgetsfrmIssues() {
    frmIssues.setDefaultUnit(kony.flex.DP);
    var flxOuter = new kony.ui.FlexContainer({
        "autogrowMode": kony.flex.AUTOGROW_NONE,
        "clipBounds": true,
        "height": "100%",
        "id": "flxOuter",
        "isVisible": true,
        "layoutType": kony.flex.FREE_FORM,
        "left": "0dp",
        "skin": "sknflxnoborder",
        "top": "0dp",
        "width": "100%"
    }, {}, {});
    flxOuter.setDefaultUnit(kony.flex.DP);
    var FlexContainer0af4ba12e07cb44 = new kony.ui.FlexContainer({
        "autogrowMode": kony.flex.AUTOGROW_NONE,
        "clipBounds": true,
        "height": "8%",
        "id": "FlexContainer0af4ba12e07cb44",
        "isVisible": true,
        "layoutType": kony.flex.FREE_FORM,
        "left": "0",
        "skin": "CopyflxBGGreen08723e3e9fec344",
        "top": "0",
        "width": "100%"
    }, {}, {});
    FlexContainer0af4ba12e07cb44.setDefaultUnit(kony.flex.DP);
    var lblTitle = new kony.ui.Label({
        "centerX": "48%",
        "centerY": "50%",
        "id": "lblTitle",
        "isVisible": true,
        "skin": "CopyslLabel0acaf0be04c9c4b",
        "text": "Issues Reported",
        "textStyle": {
            "letterSpacing": 0,
            "strikeThrough": false
        },
        "width": kony.flex.USE_PREFFERED_SIZE
    }, {
        "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
        "padding": [0, 0, 0, 0],
        "paddingInPixel": false
    }, {
        "textCopyable": false
    });
    var Image08cd7bcf5747041 = new kony.ui.Image2({
        "centerY": "50%",
        "height": "90%",
        "id": "Image08cd7bcf5747041",
        "isVisible": true,
        "left": "3%",
        "onTouchEnd": AS_Image_636198c6b2cb4170937e895827395f5c,
        "skin": "slImage",
        "src": "menuwhite.png",
        "top": "8dp",
        "width": "12%",
        "zIndex": 1
    }, {
        "imageScaleMode": constants.IMAGE_SCALE_MODE_MAINTAIN_ASPECT_RATIO,
        "padding": [0, 0, 0, 0],
        "paddingInPixel": false
    }, {});
    FlexContainer0af4ba12e07cb44.add(
    lblTitle, Image08cd7bcf5747041);
    var flxBody = new kony.ui.FlexContainer({
        "autogrowMode": kony.flex.AUTOGROW_NONE,
        "clipBounds": true,
        "height": "92%",
        "id": "flxBody",
        "isVisible": true,
        "layoutType": kony.flex.FREE_FORM,
        "left": "0dp",
        "skin": "slFbox",
        "top": "8%",
        "width": "100%",
        "zIndex": 1
    }, {}, {});
    flxBody.setDefaultUnit(kony.flex.DP);
    var segIssues = new kony.ui.SegmentedUI2({
        "autogrowMode": kony.flex.AUTOGROW_NONE,
        "data": [{
            "lblDateValue": "21 May, 2016",
            "lblFromValue": "ఒక చెట్టు రోడ్డు మీద పడిపోయింది మరియు ట్రాఫిక్ జామ్ ఉంది",
            "lblTitle": "Pending",
            "lblTo": "Road # 36, Jubilee Hills"
        }, {
            "lblDateValue": "21 May, 2016",
            "lblFromValue": "Oil spilled on the road and it is causing lot of inconvenience to the peopl on road.",
            "lblTitle": "Pending",
            "lblTo": "Shivam Road"
        }, {
            "lblDateValue": "16 May, 2016",
            "lblFromValue": "Pipe layout work done was not finished properly. Digging was not covered properly. Causing issue while driving a car",
            "lblTitle": "Resolved",
            "lblTo": "Main Road, Srinagar Colony"
        }, {
            "lblDateValue": "13 May, 2016",
            "lblFromValue": "Roads are completely washed away because of yesterday's rain. Lot of water stagnated.",
            "lblTitle": "Resolved",
            "lblTo": "Yellareddy Guda"
        }, {
            "lblDateValue": "10 May, 2016",
            "lblFromValue": "A tree fell down on the road and there is traffic jam ",
            "lblTitle": "Pending",
            "lblTo": "Chandanagar Road"
        }, {
            "lblDateValue": "09 May, 2016",
            "lblFromValue": "Because of yesterday's rain, lot of potholes came up on the road. Please fix them",
            "lblTitle": "Resolved",
            "lblTo": "NH 56, Bowenpally"
        }, {
            "lblDateValue": "03 May, 2016",
            "lblFromValue": "Oil spilled on the road and it is causing lot of inconvenience to the peopl on road.",
            "lblTitle": "Resolved",
            "lblTo": "Chandanagar RoadMain Road, Srinagar Colony"
        }, {
            "lblDateValue": "29 April, 2016",
            "lblFromValue": "Pipe layout work done was not finished properly. Digging was not covered properly. Causing issue while driving a car",
            "lblTitle": "Pending",
            "lblTo": "Road # 36, Jubilee Hills"
        }],
        "groupCells": false,
        "height": "100%",
        "id": "segIssues",
        "isVisible": true,
        "left": "0dp",
        "needPageIndicator": true,
        "onRowClick": AS_Segment_bdd3f10f5dc54ffbb9c9b33bd33eb050,
        "pageOffDotImage": "pageOffDot.png",
        "pageOnDotImage": "pageOnDot.png",
        "retainSelection": false,
        "rowFocusSkin": "seg2Focus",
        "rowSkin": "seg2Normal",
        "rowTemplate": flxSegOuter,
        "scrollingEvents": {},
        "sectionHeaderSkin": "sliPhoneSegmentHeader",
        "selectionBehavior": constants.SEGUI_DEFAULT_BEHAVIOR,
        "separatorColor": "64646400",
        "separatorRequired": true,
        "separatorThickness": 1,
        "showScrollbars": false,
        "top": "0dp",
        "viewType": constants.SEGUI_VIEW_TYPE_TABLEVIEW,
        "widgetDataMap": {
            "flxSegOuter": "flxSegOuter",
            "lblDateValue": "lblDateValue",
            "lblFromValue": "lblFromValue",
            "lblTitle": "lblTitle",
            "lblTo": "lblTo"
        },
        "width": "100%"
    }, {
        "padding": [0, 0, 0, 0],
        "paddingInPixel": false
    }, {});
    flxBody.add(
    segIssues);
    flxOuter.add(
    FlexContainer0af4ba12e07cb44, flxBody);
    var flxMenuMain = new kony.ui.FlexContainer({
        "autogrowMode": kony.flex.AUTOGROW_NONE,
        "clipBounds": true,
        "height": "92%",
        "id": "flxMenuMain",
        "isVisible": true,
        "layoutType": kony.flex.FLOW_VERTICAL,
        "right": "100%",
        "skin": "slFbox",
        "top": "8%",
        "width": "65%",
        "zIndex": 1
    }, {}, {});
    flxMenuMain.setDefaultUnit(kony.flex.DP);
    var flxLine = new kony.ui.FlexContainer({
        "autogrowMode": kony.flex.AUTOGROW_NONE,
        "centerX": "50%",
        "clipBounds": true,
        "height": "1px",
        "id": "flxLine",
        "isVisible": true,
        "layoutType": kony.flex.FREE_FORM,
        "left": "80dp",
        "skin": "sknline",
        "top": "0dp",
        "width": "100%",
        "zIndex": 1
    }, {}, {});
    flxLine.setDefaultUnit(kony.flex.DP);
    flxLine.add();
    var flxDashboard = new kony.ui.FlexContainer({
        "autogrowMode": kony.flex.AUTOGROW_NONE,
        "clipBounds": true,
        "height": "10%",
        "id": "flxDashboard",
        "isVisible": true,
        "layoutType": kony.flex.FREE_FORM,
        "left": "0dp",
        "onTouchEnd": AS_FlexContainer_24c40ab7e46b4e9b90017b29cd0e47f3,
        "skin": "slFbox",
        "top": 0,
        "width": "100%"
    }, {}, {});
    flxDashboard.setDefaultUnit(kony.flex.DP);
    var Label04125fb89a62f40 = new kony.ui.Label({
        "centerY": "50%",
        "id": "Label04125fb89a62f40",
        "isVisible": true,
        "left": "10%",
        "skin": "LBLMOBCB28FFFFFF",
        "text": "Dashboard",
        "textStyle": {
            "letterSpacing": 0,
            "strikeThrough": false
        },
        "width": kony.flex.USE_PREFFERED_SIZE
    }, {
        "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
        "padding": [0, 0, 0, 0],
        "paddingInPixel": false
    }, {
        "textCopyable": false
    });
    var CopyflxLine0fd5bfc8da0be47 = new kony.ui.FlexContainer({
        "autogrowMode": kony.flex.AUTOGROW_NONE,
        "bottom": "0dp",
        "centerX": "50%",
        "clipBounds": true,
        "height": "1px",
        "id": "CopyflxLine0fd5bfc8da0be47",
        "isVisible": true,
        "layoutType": kony.flex.FREE_FORM,
        "skin": "sknline",
        "width": "90%",
        "zIndex": 1
    }, {}, {});
    CopyflxLine0fd5bfc8da0be47.setDefaultUnit(kony.flex.DP);
    CopyflxLine0fd5bfc8da0be47.add();
    flxDashboard.add(
    Label04125fb89a62f40, CopyflxLine0fd5bfc8da0be47);
    var flxTrips = new kony.ui.FlexContainer({
        "autogrowMode": kony.flex.AUTOGROW_NONE,
        "clipBounds": true,
        "height": "10%",
        "id": "flxTrips",
        "isVisible": true,
        "layoutType": kony.flex.FREE_FORM,
        "left": "0dp",
        "onTouchEnd": AS_FlexContainer_b14a33d384c345899b5a1e6f5d950142,
        "skin": "slFbox",
        "top": "0dp",
        "width": "100%"
    }, {}, {});
    flxTrips.setDefaultUnit(kony.flex.DP);
    var CopyLabel0281cc3aac14d49 = new kony.ui.Label({
        "centerY": "50%",
        "id": "CopyLabel0281cc3aac14d49",
        "isVisible": true,
        "left": "10%",
        "skin": "LBLMOBCB28FFFFFF",
        "text": "Trips",
        "textStyle": {
            "letterSpacing": 0,
            "strikeThrough": false
        },
        "width": kony.flex.USE_PREFFERED_SIZE
    }, {
        "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
        "padding": [0, 0, 0, 0],
        "paddingInPixel": false
    }, {
        "textCopyable": false
    });
    var CopyflxLine0932af4004df445 = new kony.ui.FlexContainer({
        "autogrowMode": kony.flex.AUTOGROW_NONE,
        "bottom": "0px",
        "centerX": "50%",
        "clipBounds": true,
        "height": "1px",
        "id": "CopyflxLine0932af4004df445",
        "isVisible": true,
        "layoutType": kony.flex.FREE_FORM,
        "skin": "sknline",
        "width": "90%",
        "zIndex": 1
    }, {}, {});
    CopyflxLine0932af4004df445.setDefaultUnit(kony.flex.DP);
    CopyflxLine0932af4004df445.add();
    flxTrips.add(
    CopyLabel0281cc3aac14d49, CopyflxLine0932af4004df445);
    var flxIssues = new kony.ui.FlexContainer({
        "autogrowMode": kony.flex.AUTOGROW_NONE,
        "clipBounds": true,
        "height": "10%",
        "id": "flxIssues",
        "isVisible": true,
        "layoutType": kony.flex.FREE_FORM,
        "left": "0dp",
        "onTouchEnd": AS_FlexContainer_023d39feade44fbabf6dca8f684b6775,
        "skin": "slFbox",
        "top": "0dp",
        "width": "100%"
    }, {}, {});
    flxIssues.setDefaultUnit(kony.flex.DP);
    var CopyLabel0202755656a1046 = new kony.ui.Label({
        "centerY": "50%",
        "id": "CopyLabel0202755656a1046",
        "isVisible": true,
        "left": "10%",
        "skin": "LBLMOBCB28FFFFFF",
        "text": "Issues",
        "textStyle": {
            "letterSpacing": 0,
            "strikeThrough": false
        },
        "width": kony.flex.USE_PREFFERED_SIZE
    }, {
        "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
        "padding": [0, 0, 0, 0],
        "paddingInPixel": false
    }, {
        "textCopyable": false
    });
    var CopyflxLine0b414cfb2ffdf49 = new kony.ui.FlexContainer({
        "autogrowMode": kony.flex.AUTOGROW_NONE,
        "bottom": "0dp",
        "centerX": "50%",
        "clipBounds": true,
        "height": "1px",
        "id": "CopyflxLine0b414cfb2ffdf49",
        "isVisible": true,
        "layoutType": kony.flex.FREE_FORM,
        "skin": "sknline",
        "width": "90%",
        "zIndex": 1
    }, {}, {});
    CopyflxLine0b414cfb2ffdf49.setDefaultUnit(kony.flex.DP);
    CopyflxLine0b414cfb2ffdf49.add();
    flxIssues.add(
    CopyLabel0202755656a1046, CopyflxLine0b414cfb2ffdf49);
    var flxContractors = new kony.ui.FlexContainer({
        "autogrowMode": kony.flex.AUTOGROW_NONE,
        "clipBounds": true,
        "height": "10%",
        "id": "flxContractors",
        "isVisible": true,
        "layoutType": kony.flex.FREE_FORM,
        "left": "0dp",
        "onTouchEnd": AS_FlexContainer_b8f4e47ce98742c98169b81e39eb45f7,
        "skin": "slFbox",
        "top": "0dp",
        "width": "100%"
    }, {}, {});
    flxContractors.setDefaultUnit(kony.flex.DP);
    var CopyLabel03d0b0b7981944a = new kony.ui.Label({
        "centerY": "50%",
        "id": "CopyLabel03d0b0b7981944a",
        "isVisible": true,
        "left": "10%",
        "skin": "LBLMOBCB28FFFFFF",
        "text": "Contractors",
        "textStyle": {
            "letterSpacing": 0,
            "strikeThrough": false
        },
        "width": kony.flex.USE_PREFFERED_SIZE
    }, {
        "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
        "padding": [0, 0, 0, 0],
        "paddingInPixel": false
    }, {
        "textCopyable": false
    });
    var CopyflxLine01e956f0002f44e = new kony.ui.FlexContainer({
        "autogrowMode": kony.flex.AUTOGROW_NONE,
        "bottom": "0dp",
        "centerX": "50%",
        "clipBounds": true,
        "height": "1px",
        "id": "CopyflxLine01e956f0002f44e",
        "isVisible": true,
        "layoutType": kony.flex.FREE_FORM,
        "skin": "sknline",
        "width": "90%",
        "zIndex": 1
    }, {}, {});
    CopyflxLine01e956f0002f44e.setDefaultUnit(kony.flex.DP);
    CopyflxLine01e956f0002f44e.add();
    flxContractors.add(
    CopyLabel03d0b0b7981944a, CopyflxLine01e956f0002f44e);
    var flxLogout = new kony.ui.FlexContainer({
        "autogrowMode": kony.flex.AUTOGROW_NONE,
        "clipBounds": true,
        "height": "10%",
        "id": "flxLogout",
        "isVisible": true,
        "layoutType": kony.flex.FREE_FORM,
        "left": "0dp",
        "onTouchEnd": AS_FlexContainer_3bfba7ab121041fb8626bbf17da2732b,
        "skin": "slFbox",
        "top": "0dp",
        "width": "100%"
    }, {}, {});
    flxLogout.setDefaultUnit(kony.flex.DP);
    var CopyLabel0d0d31936215146 = new kony.ui.Label({
        "centerY": "50%",
        "id": "CopyLabel0d0d31936215146",
        "isVisible": true,
        "left": "10%",
        "skin": "LBLMOBCB28FFFFFF",
        "text": "Logout",
        "textStyle": {
            "letterSpacing": 0,
            "strikeThrough": false
        },
        "width": kony.flex.USE_PREFFERED_SIZE
    }, {
        "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
        "padding": [0, 0, 0, 0],
        "paddingInPixel": false
    }, {
        "textCopyable": false
    });
    var CopyflxLine0c6f4c764071841 = new kony.ui.FlexContainer({
        "autogrowMode": kony.flex.AUTOGROW_NONE,
        "bottom": "0dp",
        "centerX": "50%",
        "clipBounds": true,
        "height": "1px",
        "id": "CopyflxLine0c6f4c764071841",
        "isVisible": true,
        "layoutType": kony.flex.FREE_FORM,
        "skin": "sknline",
        "width": "100%",
        "zIndex": 1
    }, {}, {});
    CopyflxLine0c6f4c764071841.setDefaultUnit(kony.flex.DP);
    CopyflxLine0c6f4c764071841.add();
    flxLogout.add(
    CopyLabel0d0d31936215146, CopyflxLine0c6f4c764071841);
    flxMenuMain.add(
    flxLine, flxDashboard, flxTrips, flxIssues, flxContractors, flxLogout);
    var Image0d001317d8c3949 = new kony.ui.Image2({
        "bottom": "5%",
        "height": "50dp",
        "id": "Image0d001317d8c3949",
        "isVisible": true,
        "right": "10%",
        "skin": "slImage",
        "src": "filter.png",
        "width": "50dp",
        "zIndex": 5
    }, {
        "imageScaleMode": constants.IMAGE_SCALE_MODE_MAINTAIN_ASPECT_RATIO,
        "padding": [0, 0, 0, 0],
        "paddingInPixel": false
    }, {});
    frmIssues.add(
    flxOuter, flxMenuMain, Image0d001317d8c3949);
};

function frmIssuesGlobals() {
    frmIssues = new kony.ui.Form2({
        "addWidgets": addWidgetsfrmIssues,
        "enabledForIdleTimeout": false,
        "id": "frmIssues",
        "layoutType": kony.flex.FREE_FORM,
        "needAppMenu": false,
        "skin": "CopyslForm0959790dcc82543"
    }, {
        "displayOrientation": constants.FORM_DISPLAY_ORIENTATION_PORTRAIT,
        "layoutType": kony.flex.FREE_FORM,
        "padding": [0, 0, 0, 0],
        "paddingInPixel": false
    }, {
        "footerOverlap": false,
        "headerOverlap": false,
        "menuPosition": constants.FORM_MENU_POSITION_AFTER_APPMENU,
        "retainScrollPosition": false,
        "titleBar": true,
        "titleBarSkin": "slTitleBar",
        "windowSoftInputMode": constants.FORM_ADJUST_RESIZE
    });
};