function AS_FlexContainer_3b286f168fdc47cf9879d483cf9b4748(eventobject, x, y) {
    onClickHamburgerMenuOriginal(kony.application.getCurrentForm());
    frmLogin.show();
}