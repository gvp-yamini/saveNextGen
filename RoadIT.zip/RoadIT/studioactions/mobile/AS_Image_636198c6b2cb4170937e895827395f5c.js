function AS_Image_636198c6b2cb4170937e895827395f5c(eventobject, x, y) {
    getHamburgerMenu();
}