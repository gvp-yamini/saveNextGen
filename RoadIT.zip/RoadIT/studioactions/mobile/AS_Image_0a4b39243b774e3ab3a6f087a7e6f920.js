function AS_Image_0a4b39243b774e3ab3a6f087a7e6f920(eventobject, x, y) {
    getHamburgerMenu();
}