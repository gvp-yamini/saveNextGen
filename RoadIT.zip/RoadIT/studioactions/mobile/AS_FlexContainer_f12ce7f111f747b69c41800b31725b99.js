function AS_FlexContainer_f12ce7f111f747b69c41800b31725b99(eventobject, x, y) {
    onClickHamburgerMenuOriginal(kony.application.getCurrentForm());
    frmIssues.show();
}