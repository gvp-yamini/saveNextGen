var isMenuShown=false;

function onClickHamburgerMenu(formName) {
  	formName.flxBody.setEnabled(false);
  	//formName.flxCompleteFormBackSide.isVisible=true;
  	formName.flxMenuMain.setEnabled(true);
  	formName.flxOuter.animate(
									kony.ui.createAnimation({"100" :{ "left":"65%","stepConfig":{"timingFunction":kony.anim.EASE}}}),
									{"duration":0.5,"iterationCount":1,"delay":0,"fillMode":kony.anim.FILL_MODE_FORWARDS},
 									{"animationEnd" : function(){}});
                                                                    											
    formName.flxMenuMain.animate(
									kony.ui.createAnimation({"100" :{ "left":"0%","stepConfig":{"timingFunction":kony.anim.EASE}}}),
									{"duration":0.5,"iterationCount":1,"delay":0,"fillMode":kony.anim.FILL_MODE_FORWARDS},
 									{"animationEnd" : function(){
                                      								isMenuShown=true;
                                    							}});
  	formName.flxMenuMain.setEnabled(true);
}

function onClickHamburgerMenuOriginal(formName) {
  	formName.flxBody.setEnabled(true);
  	//formName.flxCompleteFormBackSide.isVisible=true;
  	formName.flxMenuMain.setEnabled(false);
  	formName.flxOuter.animate(
									kony.ui.createAnimation({"100" :{ "left":"0%","stepConfig":{"timingFunction":kony.anim.EASE}}}),
									{"duration":0.5,"iterationCount":1,"delay":0,"fillMode":kony.anim.FILL_MODE_FORWARDS},
 									{"animationEnd" : function(){}});
                                                                    											
    formName.flxMenuMain.animate(
									kony.ui.createAnimation({"100" :{ "left":"-65%","stepConfig":{"timingFunction":kony.anim.EASE}}}),
									{"duration":0.5,"iterationCount":1,"delay":0,"fillMode":kony.anim.FILL_MODE_FORWARDS},
 									{"animationEnd" : function(){
                                      								isMenuShown=false;
                                    							}});
  	formName.flxMenuMain.setEnabled(true);
}

function getHamburgerMenu()
{
  if(isMenuShown)
  {
    onClickHamburgerMenuOriginal(kony.application.getCurrentForm());
  }
else
  {
    onClickHamburgerMenu(kony.application.getCurrentForm());
  }
}



function regAccEvent()
	{
		shakeCount = 0;
		var events = { shake : onshake } ;
		kony.accelerometer.registerAccelerationEvents(events);
	}


function onshake()
	{
		shakeCount++;
		frmStartTrip.lblBumpsCount.text = shakeCount.toString();
	}