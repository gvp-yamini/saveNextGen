function AS_Image_874ab94c1c4f4a01b1f1def540e5152f(eventobject, x, y) {
    var Form = kony.application.getPreviousForm();
    Form.show();
}