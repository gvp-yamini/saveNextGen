function AS_Segment_f0d27e0616e44052acb873c91e33f35b(eventobject, sectionNumber, rowNumber) {
    alert(frmIssues.segIssues.data);
}