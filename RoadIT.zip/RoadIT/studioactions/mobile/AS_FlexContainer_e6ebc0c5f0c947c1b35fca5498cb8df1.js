function AS_FlexContainer_e6ebc0c5f0c947c1b35fca5498cb8df1(eventobject, x, y) {
    onClickHamburgerMenuOriginal(kony.application.getCurrentForm());
    frmIssues.show();
}