function AS_FlexContainer_b14a33d384c345899b5a1e6f5d950142(eventobject, x, y) {
    onClickHamburgerMenuOriginal(kony.application.getCurrentForm());
    frmTripList.show();
}