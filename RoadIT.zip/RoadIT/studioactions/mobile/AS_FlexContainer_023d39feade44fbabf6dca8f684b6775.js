function AS_FlexContainer_023d39feade44fbabf6dca8f684b6775(eventobject, x, y) {
    onClickHamburgerMenuOriginal(kony.application.getCurrentForm());
    frmIssues.show();
}