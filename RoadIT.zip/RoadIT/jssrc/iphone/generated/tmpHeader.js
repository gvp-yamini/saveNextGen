function initializetmpHeader() {
    FlexContainer0af4ba12e07cb44 = new kony.ui.FlexContainer({
        "autogrowMode": kony.flex.AUTOGROW_NONE,
        "clipBounds": true,
        "height": "10%",
        "id": "FlexContainer0af4ba12e07cb44",
        "isVisible": true,
        "layoutType": kony.flex.FREE_FORM,
        "skin": "CopyflxBGGreen08723e3e9fec344"
    }, {}, {});
    FlexContainer0af4ba12e07cb44.setDefaultUnit(kony.flex.DP);
    var lblTitle = new kony.ui.Label({
        "centerX": "48%",
        "centerY": "50%",
        "id": "lblTitle",
        "isVisible": true,
        "skin": "CopyslLabel0acaf0be04c9c4b",
        "text": "Road-IT",
        "width": kony.flex.USE_PREFFERED_SIZE
    }, {
        "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
        "padding": [0, 0, 0, 0],
        "paddingInPixel": false
    }, {
        "textCopyable": false,
        "wrapping": constants.WIDGET_TEXT_WORD_WRAP
    });
    var Image002b194aaed1144 = new kony.ui.Image2({
        "centerY": "50%",
        "height": "110%",
        "id": "Image002b194aaed1144",
        "isVisible": true,
        "right": "5%",
        "skin": "slImage",
        "src": "logout.png",
        "width": "10%",
        "zIndex": 1
    }, {
        "imageScaleMode": constants.IMAGE_SCALE_MODE_MAINTAIN_ASPECT_RATIO,
        "padding": [0, 0, 0, 0],
        "paddingInPixel": false
    }, {});
    FlexContainer0af4ba12e07cb44.add(
    lblTitle, Image002b194aaed1144);
}