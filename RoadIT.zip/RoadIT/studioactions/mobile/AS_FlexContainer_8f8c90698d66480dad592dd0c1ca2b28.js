function AS_FlexContainer_8f8c90698d66480dad592dd0c1ca2b28(eventobject, x, y) {
    onClickHamburgerMenuOriginal(kony.application.getCurrentForm());
    frmContractors.show();
}