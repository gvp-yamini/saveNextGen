function AS_FlexContainer_a92a718fb09949138395dc9aade39fdc(eventobject, x, y) {
    onClickHamburgerMenuOriginal(kony.application.getCurrentForm());
    frmLogin.show();
}