function AS_FlexContainer_adc0d8295ff646dd88a6c936ddf57e1b(eventobject, x, y) {
    onClickHamburgerMenuOriginal(kony.application.getCurrentForm());
    frmDashboard.show();
}