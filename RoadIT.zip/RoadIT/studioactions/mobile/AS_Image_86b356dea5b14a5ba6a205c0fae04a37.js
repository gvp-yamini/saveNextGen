function AS_Image_86b356dea5b14a5ba6a205c0fae04a37(eventobject, x, y) {
    getHamburgerMenu();
}