function initializetmpTrips() {
    FlexContainer0b52f60c4cc6949 = new kony.ui.FlexContainer({
        "autogrowMode": kony.flex.AUTOGROW_NONE,
        "clipBounds": true,
        "height": "80dp",
        "id": "FlexContainer0b52f60c4cc6949",
        "isVisible": true,
        "layoutType": kony.flex.FREE_FORM,
        "skin": "slFbox"
    }, {}, {});
    FlexContainer0b52f60c4cc6949.setDefaultUnit(kony.flex.DP);
    var lblTo = new kony.ui.Label({
        "id": "lblTo",
        "isVisible": true,
        "left": "5%",
        "skin": "sknLabel",
        "text": "To: ",
        "top": "50dp",
        "width": kony.flex.USE_PREFFERED_SIZE
    }, {
        "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
        "padding": [0, 0, 0, 0],
        "paddingInPixel": false
    }, {
        "textCopyable": false,
        "wrapping": constants.WIDGET_TEXT_WORD_WRAP
    });
    var lblDateValue = new kony.ui.Label({
        "id": "lblDateValue",
        "isVisible": true,
        "left": "5%",
        "skin": "sknlblValue",
        "text": "22nd May,2016",
        "top": "10dp",
        "width": "30%"
    }, {
        "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
        "padding": [0, 0, 0, 0],
        "paddingInPixel": false
    }, {
        "textCopyable": false,
        "wrapping": constants.WIDGET_TEXT_WORD_WRAP
    });
    var lblToValue = new kony.ui.Label({
        "id": "lblToValue",
        "isVisible": true,
        "left": "20%",
        "skin": "sknlblValue",
        "text": "Ameerpet",
        "top": "50dp",
        "width": "30%"
    }, {
        "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
        "padding": [0, 0, 0, 0],
        "paddingInPixel": false
    }, {
        "textCopyable": false,
        "wrapping": constants.WIDGET_TEXT_WORD_WRAP
    });
    var lblFrom = new kony.ui.Label({
        "id": "lblFrom",
        "isVisible": true,
        "left": "5%",
        "skin": "sknLabel",
        "text": "From: ",
        "top": "30dp",
        "width": kony.flex.USE_PREFFERED_SIZE
    }, {
        "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
        "padding": [0, 0, 0, 0],
        "paddingInPixel": false
    }, {
        "textCopyable": false,
        "wrapping": constants.WIDGET_TEXT_WORD_WRAP
    });
    var CopylblQuality0237aac80b76646 = new kony.ui.Label({
        "id": "CopylblQuality0237aac80b76646",
        "isVisible": true,
        "left": "50%",
        "skin": "sknLabel",
        "text": "#Bumps: ",
        "top": "50dp",
        "width": kony.flex.USE_PREFFERED_SIZE
    }, {
        "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
        "padding": [0, 0, 0, 0],
        "paddingInPixel": false
    }, {
        "textCopyable": false,
        "wrapping": constants.WIDGET_TEXT_WORD_WRAP
    });
    var lblFromValue = new kony.ui.Label({
        "id": "lblFromValue",
        "isVisible": true,
        "left": "20%",
        "skin": "sknlblValue",
        "text": "Lakdi ka Pool",
        "top": "30dp",
        "width": kony.flex.USE_PREFFERED_SIZE
    }, {
        "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
        "padding": [0, 0, 0, 0],
        "paddingInPixel": false
    }, {
        "textCopyable": false,
        "wrapping": constants.WIDGET_TEXT_WORD_WRAP
    });
    var CopylblFromValue0cfcbd4dda2244e = new kony.ui.Label({
        "id": "CopylblFromValue0cfcbd4dda2244e",
        "isVisible": true,
        "left": "65%",
        "skin": "sknlblValue",
        "text": "60",
        "top": "50dp",
        "width": kony.flex.USE_PREFFERED_SIZE
    }, {
        "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
        "padding": [0, 0, 0, 0],
        "paddingInPixel": false
    }, {
        "textCopyable": false,
        "wrapping": constants.WIDGET_TEXT_WORD_WRAP
    });
    var lblQualityValue = new kony.ui.Label({
        "id": "lblQualityValue",
        "isVisible": true,
        "left": "50%",
        "skin": "CopysknlblCN0c847df04dbbb40",
        "text": "8.5/10",
        "top": "10dp",
        "width": kony.flex.USE_PREFFERED_SIZE
    }, {
        "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
        "padding": [0, 0, 0, 0],
        "paddingInPixel": false
    }, {
        "textCopyable": false,
        "wrapping": constants.WIDGET_TEXT_WORD_WRAP
    });
    var Button0a343b7d7f58742 = new kony.ui.Button({
        "centerY": "50%",
        "focusSkin": "CopysknBtnFocus0e2463c98f87340",
        "height": "30%",
        "id": "Button0a343b7d7f58742",
        "isVisible": true,
        "left": "76%",
        "onClick": AS_Button_390df827719840cf942c35e6522b4ffd,
        "skin": "CopysknBtnFF0a8c20971c6eb4e",
        "text": "Contribute",
        "top": "17dp",
        "width": "21%",
        "zIndex": 1
    }, {
        "contentAlignment": constants.CONTENT_ALIGN_CENTER,
        "displayText": true,
        "padding": [0, 0, 0, 0],
        "paddingInPixel": false
    }, {
        "showProgressIndicator": true
    });
    FlexContainer0b52f60c4cc6949.add(
    lblTo, lblDateValue, lblToValue, lblFrom, CopylblQuality0237aac80b76646, lblFromValue, CopylblFromValue0cfcbd4dda2244e, lblQualityValue, Button0a343b7d7f58742);
}