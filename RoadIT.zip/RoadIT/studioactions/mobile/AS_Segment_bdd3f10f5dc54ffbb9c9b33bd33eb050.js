function AS_Segment_bdd3f10f5dc54ffbb9c9b33bd33eb050(eventobject, sectionNumber, rowNumber) {
    frmIssue.ImgCaptured.src = "tree.png";
    frmIssue.btnStartTrip.setVisibility(false);
    frmIssue.TextArea08ea20b91246d44.text = "A tree fell down on the road and there is traffic jam.";
    frmIssue.TextArea08ea20b91246d44.setEnabled(false);
    frmIssue.show();
}