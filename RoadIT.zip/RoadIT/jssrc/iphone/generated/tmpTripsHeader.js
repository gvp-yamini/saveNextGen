function initializetmpTripsHeader() {
    FlexContainer01ddd6bbb88364b = new kony.ui.FlexContainer({
        "autogrowMode": kony.flex.AUTOGROW_NONE,
        "clipBounds": true,
        "height": "30dp",
        "id": "FlexContainer01ddd6bbb88364b",
        "isVisible": true,
        "layoutType": kony.flex.FREE_FORM,
        "skin": "CopyflexHead0cd45563d947e46"
    }, {}, {});
    FlexContainer01ddd6bbb88364b.setDefaultUnit(kony.flex.DP);
    var Label05d038c6e204a48 = new kony.ui.Label({
        "centerY": "50%",
        "id": "Label05d038c6e204a48",
        "isVisible": true,
        "left": "5%",
        "skin": "CopysknlblCN0cc7dc27c8d4a42",
        "text": "Today",
        "top": "3dp",
        "width": kony.flex.USE_PREFFERED_SIZE
    }, {
        "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
        "padding": [0, 0, 0, 0],
        "paddingInPixel": false
    }, {
        "textCopyable": false,
        "wrapping": constants.WIDGET_TEXT_WORD_WRAP
    });
    FlexContainer01ddd6bbb88364b.add(
    Label05d038c6e204a48);
}