function AS_FlexContainer_b8f4e47ce98742c98169b81e39eb45f7(eventobject, x, y) {
    onClickHamburgerMenuOriginal(kony.application.getCurrentForm());
    frmContractors.show();
}