function AS_Image_d7498497efad40809382649a907c9ed3(eventobject, x, y) {
    frmDashboard.show();
}