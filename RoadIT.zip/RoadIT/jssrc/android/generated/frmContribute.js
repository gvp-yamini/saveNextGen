function addWidgetsfrmContribute() {
    frmContribute.setDefaultUnit(kony.flex.DP);
    var FlexContainer0af4ba12e07cb44 = new kony.ui.FlexContainer({
        "autogrowMode": kony.flex.AUTOGROW_NONE,
        "clipBounds": true,
        "height": "8%",
        "id": "FlexContainer0af4ba12e07cb44",
        "isVisible": true,
        "layoutType": kony.flex.FREE_FORM,
        "left": "0",
        "skin": "CopyflxBGGreen08723e3e9fec344",
        "top": "0%",
        "width": "100%"
    }, {}, {});
    FlexContainer0af4ba12e07cb44.setDefaultUnit(kony.flex.DP);
    var lblTitle = new kony.ui.Label({
        "centerX": "48%",
        "centerY": "50%",
        "id": "lblTitle",
        "isVisible": true,
        "skin": "CopyslLabel0acaf0be04c9c4b",
        "text": "Contribute",
        "textStyle": {
            "letterSpacing": 0,
            "strikeThrough": false
        },
        "width": kony.flex.USE_PREFFERED_SIZE
    }, {
        "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
        "padding": [0, 0, 0, 0],
        "paddingInPixel": false
    }, {
        "textCopyable": false
    });
    var Image0cc7265d9637545 = new kony.ui.Image2({
        "centerY": "50%",
        "height": "90%",
        "id": "Image0cc7265d9637545",
        "isVisible": true,
        "left": "0%",
        "onTouchEnd": AS_Image_9a9f42409ea344d993a42b4237692602,
        "skin": "slImage",
        "src": "backwhite.png",
        "top": "12dp",
        "width": "12%",
        "zIndex": 1
    }, {
        "imageScaleMode": constants.IMAGE_SCALE_MODE_MAINTAIN_ASPECT_RATIO,
        "padding": [0, 0, 0, 0],
        "paddingInPixel": false
    }, {});
    FlexContainer0af4ba12e07cb44.add(
    lblTitle, Image0cc7265d9637545);
    var FlexContainer0453e7e008def4b = new kony.ui.FlexContainer({
        "autogrowMode": kony.flex.AUTOGROW_NONE,
        "clipBounds": true,
        "height": "92%",
        "id": "FlexContainer0453e7e008def4b",
        "isVisible": true,
        "layoutType": kony.flex.FREE_FORM,
        "left": "0dp",
        "skin": "sknflxnoborder",
        "top": "8%",
        "width": "100%",
        "zIndex": 1
    }, {}, {});
    FlexContainer0453e7e008def4b.setDefaultUnit(kony.flex.DP);
    var FlexContainer0403b4c10d0854a = new kony.ui.FlexContainer({
        "autogrowMode": kony.flex.AUTOGROW_NONE,
        "clipBounds": true,
        "height": "62%",
        "id": "FlexContainer0403b4c10d0854a",
        "isVisible": true,
        "layoutType": kony.flex.FLOW_VERTICAL,
        "left": "0dp",
        "skin": "slFbox",
        "top": "0dp",
        "width": "100%"
    }, {}, {});
    FlexContainer0403b4c10d0854a.setDefaultUnit(kony.flex.DP);
    var Label016652b2ebd014c = new kony.ui.Label({
        "id": "Label016652b2ebd014c",
        "isVisible": true,
        "left": "5%",
        "skin": "CopysknlblCN051dda18a396c4f",
        "text": "Contribute For Road #10, Yousaf Guda",
        "textStyle": {
            "letterSpacing": 0,
            "strikeThrough": false
        },
        "top": "4%",
        "width": kony.flex.USE_PREFFERED_SIZE,
        "zIndex": 1
    }, {
        "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
        "padding": [0, 0, 0, 0],
        "paddingInPixel": false
    }, {
        "textCopyable": false
    });
    var Label0c4d1533f5ef547 = new kony.ui.Label({
        "id": "Label0c4d1533f5ef547",
        "isVisible": true,
        "left": "5%",
        "skin": "CopysknLabel0a8fa3c3c528241",
        "text": "Select your preferred days:",
        "textStyle": {
            "letterSpacing": 0,
            "strikeThrough": false
        },
        "top": "5%",
        "width": kony.flex.USE_PREFFERED_SIZE
    }, {
        "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
        "padding": [0, 0, 0, 0],
        "paddingInPixel": false
    }, {
        "textCopyable": false
    });
    var CheckBoxGroup07da891084b2146 = new kony.ui.CheckBoxGroup({
        "centerX": "50%",
        "height": "85%",
        "id": "CheckBoxGroup07da891084b2146",
        "isVisible": true,
        "left": "0dp",
        "masterData": [
            ["cbg1", "Sunday"],
            ["cbg2", "Monday"],
            ["cbg3", "Tuesday"],
            ["Key868", "Wednesday"],
            ["Key862", "Thursday"],
            ["Key497", "Friday"],
            ["Key934", "Saturday"]
        ],
        "skin": "CopyslCheckBoxGroup0e6f98caf1de04d",
        "top": "3%",
        "width": "90%",
        "zIndex": 1
    }, {
        "itemOrientation": constants.CHECKBOX_ITEM_ORIENTATION_VERTICAL,
        "padding": [5, 0, 0, 0],
        "paddingInPixel": false
    }, {});
    FlexContainer0403b4c10d0854a.add(
    Label016652b2ebd014c, Label0c4d1533f5ef547, CheckBoxGroup07da891084b2146);
    var FlexContainer0fda57fc6851c46 = new kony.ui.FlexContainer({
        "autogrowMode": kony.flex.AUTOGROW_NONE,
        "clipBounds": true,
        "height": "17%",
        "id": "FlexContainer0fda57fc6851c46",
        "isVisible": true,
        "layoutType": kony.flex.FREE_FORM,
        "left": "0dp",
        "skin": "slFbox",
        "top": "62%",
        "width": "100%",
        "zIndex": 1
    }, {}, {});
    FlexContainer0fda57fc6851c46.setDefaultUnit(kony.flex.DP);
    var CopyLabel002cbf2eadd5241 = new kony.ui.Label({
        "id": "CopyLabel002cbf2eadd5241",
        "isVisible": true,
        "left": "5%",
        "skin": "CopysknLabel0a8fa3c3c528241",
        "text": "Select Suitable Timings:",
        "textStyle": {
            "letterSpacing": 0,
            "strikeThrough": false
        },
        "top": "10%",
        "width": kony.flex.USE_PREFFERED_SIZE
    }, {
        "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
        "padding": [0, 0, 0, 0],
        "paddingInPixel": false
    }, {
        "textCopyable": false
    });
    var ListBox0a877069bd4564d = new kony.ui.ListBox({
        "centerX": "50%",
        "height": "40dp",
        "id": "ListBox0a877069bd4564d",
        "isVisible": true,
        "left": "23dp",
        "masterData": [
            ["lb1", "6 AM to 9 AM"],
            ["lb2", "12 PM to 3 PM"],
            ["lb3", "4 PM to 7 PM"]
        ],
        "skin": "slListBox",
        "top": "50%",
        "width": "90%",
        "zIndex": 1
    }, {
        "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
        "padding": [0, 0, 0, 0],
        "paddingInPixel": false
    }, {
        "applySkinsToPopup": true,
        "viewType": constants.LISTBOX_VIEW_TYPE_LISTVIEW
    });
    FlexContainer0fda57fc6851c46.add(
    CopyLabel002cbf2eadd5241, ListBox0a877069bd4564d);
    var FlexContainer0de3c4083312841 = new kony.ui.FlexContainer({
        "autogrowMode": kony.flex.AUTOGROW_NONE,
        "clipBounds": true,
        "height": "18%",
        "id": "FlexContainer0de3c4083312841",
        "isVisible": true,
        "layoutType": kony.flex.FREE_FORM,
        "left": "0dp",
        "skin": "slFbox",
        "top": "80%",
        "width": "100%",
        "zIndex": 1
    }, {}, {});
    FlexContainer0de3c4083312841.setDefaultUnit(kony.flex.DP);
    var btnStartTrip = new kony.ui.Button({
        "centerX": "50.00%",
        "centerY": "50%",
        "focusSkin": "sknBtnFocus",
        "height": "40%",
        "id": "btnStartTrip",
        "isVisible": true,
        "left": "5%",
        "onClick": AS_Button_463f1599c45943cbb4c19d2778f74500,
        "skin": "sknBtnFF5D6E",
        "text": "Submit",
        "top": "4%",
        "width": "80%"
    }, {
        "contentAlignment": constants.CONTENT_ALIGN_CENTER,
        "displayText": true,
        "padding": [0, 0, 0, 0],
        "paddingInPixel": false
    }, {});
    FlexContainer0de3c4083312841.add(
    btnStartTrip);
    FlexContainer0453e7e008def4b.add(
    FlexContainer0403b4c10d0854a, FlexContainer0fda57fc6851c46, FlexContainer0de3c4083312841);
    frmContribute.add(
    FlexContainer0af4ba12e07cb44, FlexContainer0453e7e008def4b);
};

function frmContributeGlobals() {
    frmContribute = new kony.ui.Form2({
        "addWidgets": addWidgetsfrmContribute,
        "enabledForIdleTimeout": false,
        "id": "frmContribute",
        "layoutType": kony.flex.FREE_FORM,
        "needAppMenu": false,
        "skin": "CopyslForm0a29b8f3dd0ee42"
    }, {
        "displayOrientation": constants.FORM_DISPLAY_ORIENTATION_PORTRAIT,
        "layoutType": kony.flex.FREE_FORM,
        "padding": [0, 0, 0, 0],
        "paddingInPixel": false
    }, {
        "footerOverlap": false,
        "headerOverlap": false,
        "menuPosition": constants.FORM_MENU_POSITION_AFTER_APPMENU,
        "retainScrollPosition": false,
        "titleBar": true,
        "titleBarSkin": "slTitleBar",
        "windowSoftInputMode": constants.FORM_ADJUST_RESIZE
    });
};