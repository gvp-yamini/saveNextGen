function AS_FlexContainer_3bfba7ab121041fb8626bbf17da2732b(eventobject, x, y) {
    onClickHamburgerMenuOriginal(kony.application.getCurrentForm());
    frmLogin.show();
}