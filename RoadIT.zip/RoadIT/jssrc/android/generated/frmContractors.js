function addWidgetsfrmContractors() {
    frmContractors.setDefaultUnit(kony.flex.DP);
    var flxOuter = new kony.ui.FlexContainer({
        "autogrowMode": kony.flex.AUTOGROW_NONE,
        "clipBounds": true,
        "height": "100%",
        "id": "flxOuter",
        "isVisible": true,
        "layoutType": kony.flex.FREE_FORM,
        "left": "0dp",
        "skin": "slFbox",
        "top": "0dp",
        "width": "100%"
    }, {}, {});
    flxOuter.setDefaultUnit(kony.flex.DP);
    var FlexContainer0af4ba12e07cb44 = new kony.ui.FlexContainer({
        "autogrowMode": kony.flex.AUTOGROW_NONE,
        "clipBounds": true,
        "height": "8%",
        "id": "FlexContainer0af4ba12e07cb44",
        "isVisible": true,
        "layoutType": kony.flex.FREE_FORM,
        "left": "0",
        "skin": "CopyflxBGGreen08723e3e9fec344",
        "top": "0",
        "width": "100%"
    }, {}, {});
    FlexContainer0af4ba12e07cb44.setDefaultUnit(kony.flex.DP);
    var lblTitle = new kony.ui.Label({
        "centerX": "48%",
        "centerY": "50%",
        "id": "lblTitle",
        "isVisible": true,
        "skin": "CopyslLabel0acaf0be04c9c4b",
        "text": "Contractors",
        "textStyle": {
            "letterSpacing": 0,
            "strikeThrough": false
        },
        "width": kony.flex.USE_PREFFERED_SIZE
    }, {
        "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
        "padding": [0, 0, 0, 0],
        "paddingInPixel": false
    }, {
        "textCopyable": false
    });
    var Image08cd7bcf5747041 = new kony.ui.Image2({
        "centerY": "50%",
        "height": "90%",
        "id": "Image08cd7bcf5747041",
        "isVisible": true,
        "left": "3%",
        "onTouchEnd": AS_Image_0a4b39243b774e3ab3a6f087a7e6f920,
        "skin": "slImage",
        "src": "menuwhite.png",
        "top": "8dp",
        "width": "12%",
        "zIndex": 1
    }, {
        "imageScaleMode": constants.IMAGE_SCALE_MODE_MAINTAIN_ASPECT_RATIO,
        "padding": [0, 0, 0, 0],
        "paddingInPixel": false
    }, {});
    FlexContainer0af4ba12e07cb44.add(
    lblTitle, Image08cd7bcf5747041);
    var flxBody = new kony.ui.FlexContainer({
        "autogrowMode": kony.flex.AUTOGROW_NONE,
        "clipBounds": true,
        "height": "92%",
        "id": "flxBody",
        "isVisible": true,
        "layoutType": kony.flex.FREE_FORM,
        "left": "0dp",
        "skin": "sknflxnoborder",
        "top": "8%",
        "width": "100%",
        "zIndex": 1
    }, {}, {});
    flxBody.setDefaultUnit(kony.flex.DP);
    var Segment0677af441f9f84e = new kony.ui.SegmentedUI2({
        "autogrowMode": kony.flex.AUTOGROW_NONE,
        "data": [{
            "CopyImage0113dd71922bd4b": "unrated.png",
            "CopyImage0190495ce5bc748": "rated.png",
            "CopyImage02aeda0506e3b4b": "rated.png",
            "CopyImage0e183017d17f642": "rated.png",
            "CopyLabel02e8109dc084d44": "#7556",
            "Image09d4297c0dd464f": "rated.png",
            "Image0fe6d245e6f994c": "c1.png",
            "Label06dfb540e869848": "Galaxy Geomatics",
            "Label0fde795e17a674d": "Road Construction"
        }, {
            "CopyImage0113dd71922bd4b": "unrated.png",
            "CopyImage0190495ce5bc748": "rated.png",
            "CopyImage02aeda0506e3b4b": "rated.png",
            "CopyImage0e183017d17f642": "unrated.png",
            "CopyLabel02e8109dc084d44": "#1990",
            "Image09d4297c0dd464f": "rated.png",
            "Image0fe6d245e6f994c": "c2.png",
            "Label06dfb540e869848": "Swaran Tollway",
            "Label0fde795e17a674d": "Highways"
        }, {
            "CopyImage0113dd71922bd4b": "unrated.png",
            "CopyImage0190495ce5bc748": "rated.png",
            "CopyImage02aeda0506e3b4b": "rated.png",
            "CopyImage0e183017d17f642": "unrated.png",
            "CopyLabel02e8109dc084d44": "#8782",
            "Image09d4297c0dd464f": "rated.png",
            "Image0fe6d245e6f994c": "c3.png",
            "Label06dfb540e869848": "ACB Infrastructure Ltd",
            "Label0fde795e17a674d": "Road Construction"
        }, {
            "CopyImage0113dd71922bd4b": "unrated.png",
            "CopyImage0190495ce5bc748": "rated.png",
            "CopyImage02aeda0506e3b4b": "unrated.png",
            "CopyImage0e183017d17f642": "unrated.png",
            "CopyLabel02e8109dc084d44": "#5589",
            "Image09d4297c0dd464f": "rated.png",
            "Image0fe6d245e6f994c": "c4.png",
            "Label06dfb540e869848": "LCC Buildcon Ltd",
            "Label0fde795e17a674d": "Construction"
        }, {
            "CopyImage0113dd71922bd4b": "unrated.png",
            "CopyImage0190495ce5bc748": "rated.png",
            "CopyImage02aeda0506e3b4b": "rated.png",
            "CopyImage0e183017d17f642": "rated.png",
            "CopyLabel02e8109dc084d44": "#12203",
            "Image09d4297c0dd464f": "rated.png",
            "Image0fe6d245e6f994c": "c5.png",
            "Label06dfb540e869848": "HSA Constructors",
            "Label0fde795e17a674d": "Grading Work"
        }],
        "groupCells": false,
        "height": "92%",
        "id": "Segment0677af441f9f84e",
        "isVisible": true,
        "left": "0dp",
        "needPageIndicator": true,
        "pageOffDotImage": "pageOffDot.png",
        "pageOnDotImage": "pageOnDot.png",
        "retainSelection": false,
        "rowFocusSkin": "seg2Focus",
        "rowSkin": "seg2Normal",
        "rowTemplate": FlexContainer0266fa20c665144,
        "scrollingEvents": {},
        "sectionHeaderSkin": "sliPhoneSegmentHeader",
        "selectionBehavior": constants.SEGUI_DEFAULT_BEHAVIOR,
        "separatorRequired": false,
        "separatorThickness": 0,
        "showScrollbars": false,
        "top": "7.50%",
        "viewType": constants.SEGUI_VIEW_TYPE_TABLEVIEW,
        "widgetDataMap": {
            "CopyImage0113dd71922bd4b": "CopyImage0113dd71922bd4b",
            "CopyImage0190495ce5bc748": "CopyImage0190495ce5bc748",
            "CopyImage02aeda0506e3b4b": "CopyImage02aeda0506e3b4b",
            "CopyImage0e183017d17f642": "CopyImage0e183017d17f642",
            "CopyLabel02e8109dc084d44": "CopyLabel02e8109dc084d44",
            "FlexContainer0266fa20c665144": "FlexContainer0266fa20c665144",
            "FlexContainer0758cc1a9369245": "FlexContainer0758cc1a9369245",
            "FlexContainer088bbdb12387547": "FlexContainer088bbdb12387547",
            "Image09d4297c0dd464f": "Image09d4297c0dd464f",
            "Image0fe6d245e6f994c": "Image0fe6d245e6f994c",
            "Label06dfb540e869848": "Label06dfb540e869848",
            "Label0fde795e17a674d": "Label0fde795e17a674d",
            "flxMain": "flxMain"
        },
        "width": "100%"
    }, {
        "padding": [0, 0, 0, 0],
        "paddingInPixel": false
    }, {});
    var TextField008c9743ad7404e = new kony.ui.TextBox2({
        "autoCapitalize": constants.TEXTBOX_AUTO_CAPITALIZE_NONE,
        "centerX": "50%",
        "height": "6%",
        "id": "TextField008c9743ad7404e",
        "isVisible": true,
        "keyBoardStyle": constants.TEXTBOX_KEY_BOARD_STYLE_DEFAULT,
        "left": "95dp",
        "placeholder": "Search Contractors",
        "secureTextEntry": false,
        "skin": "CopyslTextBox0c51c4e3be11f47",
        "textInputMode": constants.TEXTBOX_INPUT_MODE_ANY,
        "top": "1%",
        "width": "95%",
        "zIndex": 1
    }, {
        "containerHeightMode": constants.TEXTBOX_FONT_METRICS_DRIVEN_HEIGHT,
        "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
        "padding": [3, 0, 0, 0],
        "paddingInPixel": false
    }, {
        "autoFilter": false,
        "keyboardActionLabel": constants.TEXTBOX_KEYBOARD_LABEL_DEFAULT,
        "viewType": constants.TEXTBOX_VIEW_TYPE_SEARCH_VIEW
    });
    flxBody.add(
    Segment0677af441f9f84e, TextField008c9743ad7404e);
    flxOuter.add(
    FlexContainer0af4ba12e07cb44, flxBody);
    var flxMenuMain = new kony.ui.FlexContainer({
        "autogrowMode": kony.flex.AUTOGROW_NONE,
        "clipBounds": true,
        "height": "92%",
        "id": "flxMenuMain",
        "isVisible": true,
        "layoutType": kony.flex.FLOW_VERTICAL,
        "right": "100%",
        "skin": "slFbox",
        "top": "8%",
        "width": "65%",
        "zIndex": 1
    }, {}, {});
    flxMenuMain.setDefaultUnit(kony.flex.DP);
    var flxLine = new kony.ui.FlexContainer({
        "autogrowMode": kony.flex.AUTOGROW_NONE,
        "centerX": "50%",
        "clipBounds": true,
        "height": "1px",
        "id": "flxLine",
        "isVisible": true,
        "layoutType": kony.flex.FREE_FORM,
        "left": "80dp",
        "skin": "sknline",
        "top": "0dp",
        "width": "100%",
        "zIndex": 1
    }, {}, {});
    flxLine.setDefaultUnit(kony.flex.DP);
    flxLine.add();
    var flxDashboard = new kony.ui.FlexContainer({
        "autogrowMode": kony.flex.AUTOGROW_NONE,
        "clipBounds": true,
        "height": "10%",
        "id": "flxDashboard",
        "isVisible": true,
        "layoutType": kony.flex.FREE_FORM,
        "left": "0dp",
        "onTouchEnd": AS_FlexContainer_9f8816ad01314494be7c369ee7fafbe3,
        "skin": "slFbox",
        "top": 0,
        "width": "100%"
    }, {}, {});
    flxDashboard.setDefaultUnit(kony.flex.DP);
    var Label04125fb89a62f40 = new kony.ui.Label({
        "centerY": "50%",
        "id": "Label04125fb89a62f40",
        "isVisible": true,
        "left": "10%",
        "skin": "LBLMOBCB28FFFFFF",
        "text": "Dashboard",
        "textStyle": {
            "letterSpacing": 0,
            "strikeThrough": false
        },
        "width": kony.flex.USE_PREFFERED_SIZE
    }, {
        "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
        "padding": [0, 0, 0, 0],
        "paddingInPixel": false
    }, {
        "textCopyable": false
    });
    var CopyflxLine0fd5bfc8da0be47 = new kony.ui.FlexContainer({
        "autogrowMode": kony.flex.AUTOGROW_NONE,
        "bottom": "0dp",
        "centerX": "50%",
        "clipBounds": true,
        "height": "1px",
        "id": "CopyflxLine0fd5bfc8da0be47",
        "isVisible": true,
        "layoutType": kony.flex.FREE_FORM,
        "skin": "sknline",
        "width": "90%",
        "zIndex": 1
    }, {}, {});
    CopyflxLine0fd5bfc8da0be47.setDefaultUnit(kony.flex.DP);
    CopyflxLine0fd5bfc8da0be47.add();
    flxDashboard.add(
    Label04125fb89a62f40, CopyflxLine0fd5bfc8da0be47);
    var flxTrips = new kony.ui.FlexContainer({
        "autogrowMode": kony.flex.AUTOGROW_NONE,
        "clipBounds": true,
        "height": "10%",
        "id": "flxTrips",
        "isVisible": true,
        "layoutType": kony.flex.FREE_FORM,
        "left": "0dp",
        "onTouchEnd": AS_FlexContainer_80196141f9f9403d99bcea3b560a7bf7,
        "skin": "slFbox",
        "top": "0dp",
        "width": "100%"
    }, {}, {});
    flxTrips.setDefaultUnit(kony.flex.DP);
    var CopyLabel0281cc3aac14d49 = new kony.ui.Label({
        "centerY": "50%",
        "id": "CopyLabel0281cc3aac14d49",
        "isVisible": true,
        "left": "10%",
        "skin": "LBLMOBCB28FFFFFF",
        "text": "Trips",
        "textStyle": {
            "letterSpacing": 0,
            "strikeThrough": false
        },
        "width": kony.flex.USE_PREFFERED_SIZE
    }, {
        "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
        "padding": [0, 0, 0, 0],
        "paddingInPixel": false
    }, {
        "textCopyable": false
    });
    var CopyflxLine0932af4004df445 = new kony.ui.FlexContainer({
        "autogrowMode": kony.flex.AUTOGROW_NONE,
        "bottom": "0px",
        "centerX": "50%",
        "clipBounds": true,
        "height": "1px",
        "id": "CopyflxLine0932af4004df445",
        "isVisible": true,
        "layoutType": kony.flex.FREE_FORM,
        "skin": "sknline",
        "width": "90%",
        "zIndex": 1
    }, {}, {});
    CopyflxLine0932af4004df445.setDefaultUnit(kony.flex.DP);
    CopyflxLine0932af4004df445.add();
    flxTrips.add(
    CopyLabel0281cc3aac14d49, CopyflxLine0932af4004df445);
    var flxIssues = new kony.ui.FlexContainer({
        "autogrowMode": kony.flex.AUTOGROW_NONE,
        "clipBounds": true,
        "height": "10%",
        "id": "flxIssues",
        "isVisible": true,
        "layoutType": kony.flex.FREE_FORM,
        "left": "0dp",
        "onTouchEnd": AS_FlexContainer_e6ebc0c5f0c947c1b35fca5498cb8df1,
        "skin": "slFbox",
        "top": "0dp",
        "width": "100%"
    }, {}, {});
    flxIssues.setDefaultUnit(kony.flex.DP);
    var CopyLabel0202755656a1046 = new kony.ui.Label({
        "centerY": "50%",
        "id": "CopyLabel0202755656a1046",
        "isVisible": true,
        "left": "10%",
        "skin": "LBLMOBCB28FFFFFF",
        "text": "Issues",
        "textStyle": {
            "letterSpacing": 0,
            "strikeThrough": false
        },
        "width": kony.flex.USE_PREFFERED_SIZE
    }, {
        "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
        "padding": [0, 0, 0, 0],
        "paddingInPixel": false
    }, {
        "textCopyable": false
    });
    var CopyflxLine0b414cfb2ffdf49 = new kony.ui.FlexContainer({
        "autogrowMode": kony.flex.AUTOGROW_NONE,
        "bottom": "0dp",
        "centerX": "50%",
        "clipBounds": true,
        "height": "1px",
        "id": "CopyflxLine0b414cfb2ffdf49",
        "isVisible": true,
        "layoutType": kony.flex.FREE_FORM,
        "skin": "sknline",
        "width": "90%",
        "zIndex": 1
    }, {}, {});
    CopyflxLine0b414cfb2ffdf49.setDefaultUnit(kony.flex.DP);
    CopyflxLine0b414cfb2ffdf49.add();
    flxIssues.add(
    CopyLabel0202755656a1046, CopyflxLine0b414cfb2ffdf49);
    var flxContractors = new kony.ui.FlexContainer({
        "autogrowMode": kony.flex.AUTOGROW_NONE,
        "clipBounds": true,
        "height": "10%",
        "id": "flxContractors",
        "isVisible": true,
        "layoutType": kony.flex.FREE_FORM,
        "left": "0dp",
        "onTouchEnd": AS_FlexContainer_dcfc353f260d47fc88e87e3a4a33d342,
        "skin": "slFbox",
        "top": "0dp",
        "width": "100%"
    }, {}, {});
    flxContractors.setDefaultUnit(kony.flex.DP);
    var CopyLabel03d0b0b7981944a = new kony.ui.Label({
        "centerY": "50%",
        "id": "CopyLabel03d0b0b7981944a",
        "isVisible": true,
        "left": "10%",
        "skin": "LBLMOBCB28FFFFFF",
        "text": "Contractors",
        "textStyle": {
            "letterSpacing": 0,
            "strikeThrough": false
        },
        "width": kony.flex.USE_PREFFERED_SIZE
    }, {
        "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
        "padding": [0, 0, 0, 0],
        "paddingInPixel": false
    }, {
        "textCopyable": false
    });
    var CopyflxLine01e956f0002f44e = new kony.ui.FlexContainer({
        "autogrowMode": kony.flex.AUTOGROW_NONE,
        "bottom": "0dp",
        "centerX": "50%",
        "clipBounds": true,
        "height": "1px",
        "id": "CopyflxLine01e956f0002f44e",
        "isVisible": true,
        "layoutType": kony.flex.FREE_FORM,
        "skin": "sknline",
        "width": "90%",
        "zIndex": 1
    }, {}, {});
    CopyflxLine01e956f0002f44e.setDefaultUnit(kony.flex.DP);
    CopyflxLine01e956f0002f44e.add();
    flxContractors.add(
    CopyLabel03d0b0b7981944a, CopyflxLine01e956f0002f44e);
    var flxLogout = new kony.ui.FlexContainer({
        "autogrowMode": kony.flex.AUTOGROW_NONE,
        "clipBounds": true,
        "height": "10%",
        "id": "flxLogout",
        "isVisible": true,
        "layoutType": kony.flex.FREE_FORM,
        "left": "0dp",
        "onTouchEnd": AS_FlexContainer_a92a718fb09949138395dc9aade39fdc,
        "skin": "slFbox",
        "top": "0dp",
        "width": "100%"
    }, {}, {});
    flxLogout.setDefaultUnit(kony.flex.DP);
    var CopyLabel0d0d31936215146 = new kony.ui.Label({
        "centerY": "50%",
        "id": "CopyLabel0d0d31936215146",
        "isVisible": true,
        "left": "10%",
        "skin": "LBLMOBCB28FFFFFF",
        "text": "Logout",
        "textStyle": {
            "letterSpacing": 0,
            "strikeThrough": false
        },
        "width": kony.flex.USE_PREFFERED_SIZE
    }, {
        "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
        "padding": [0, 0, 0, 0],
        "paddingInPixel": false
    }, {
        "textCopyable": false
    });
    var CopyflxLine0c6f4c764071841 = new kony.ui.FlexContainer({
        "autogrowMode": kony.flex.AUTOGROW_NONE,
        "bottom": "0dp",
        "centerX": "50%",
        "clipBounds": true,
        "height": "1px",
        "id": "CopyflxLine0c6f4c764071841",
        "isVisible": true,
        "layoutType": kony.flex.FREE_FORM,
        "skin": "sknline",
        "width": "100%",
        "zIndex": 1
    }, {}, {});
    CopyflxLine0c6f4c764071841.setDefaultUnit(kony.flex.DP);
    CopyflxLine0c6f4c764071841.add();
    flxLogout.add(
    CopyLabel0d0d31936215146, CopyflxLine0c6f4c764071841);
    flxMenuMain.add(
    flxLine, flxDashboard, flxTrips, flxIssues, flxContractors, flxLogout);
    frmContractors.add(
    flxOuter, flxMenuMain);
};

function frmContractorsGlobals() {
    frmContractors = new kony.ui.Form2({
        "addWidgets": addWidgetsfrmContractors,
        "bounces": false,
        "enabledForIdleTimeout": false,
        "id": "frmContractors",
        "layoutType": kony.flex.FREE_FORM,
        "needAppMenu": false,
        "skin": "CopyslForm0959790dcc82543"
    }, {
        "displayOrientation": constants.FORM_DISPLAY_ORIENTATION_PORTRAIT,
        "layoutType": kony.flex.FREE_FORM,
        "padding": [0, 0, 0, 0],
        "paddingInPixel": false
    }, {
        "footerOverlap": false,
        "headerOverlap": false,
        "menuPosition": constants.FORM_MENU_POSITION_AFTER_APPMENU,
        "retainScrollPosition": false,
        "titleBar": true,
        "titleBarSkin": "slTitleBar",
        "windowSoftInputMode": constants.FORM_ADJUST_RESIZE
    });
};