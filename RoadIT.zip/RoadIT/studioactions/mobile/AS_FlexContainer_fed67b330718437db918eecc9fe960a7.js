function AS_FlexContainer_fed67b330718437db918eecc9fe960a7(eventobject, x, y) {
    onClickHamburgerMenuOriginal(kony.application.getCurrentForm());
    frmContractors.show();
}