function addWidgetsfrmLogin() {
    frmLogin.setDefaultUnit(kony.flex.DP);
    var flxOuter = new kony.ui.FlexContainer({
        "autogrowMode": kony.flex.AUTOGROW_NONE,
        "clipBounds": true,
        "height": "100%",
        "id": "flxOuter",
        "isVisible": true,
        "layoutType": kony.flex.FLOW_VERTICAL,
        "left": "0dp",
        "skin": "flxBGGreen",
        "top": "0dp",
        "width": "100%"
    }, {}, {});
    flxOuter.setDefaultUnit(kony.flex.DP);
    var Label0ddb9e0e74d8d42 = new kony.ui.Label({
        "centerX": "50%",
        "id": "Label0ddb9e0e74d8d42",
        "isVisible": true,
        "skin": "CopyslLabel0754cfe2c480d4a",
        "text": "Road-IT",
        "top": "15%",
        "width": "100%",
        "zIndex": 1
    }, {
        "contentAlignment": constants.CONTENT_ALIGN_CENTER,
        "padding": [0, 0, 6, 0],
        "paddingInPixel": false
    }, {
        "textCopyable": false,
        "wrapping": constants.WIDGET_TEXT_WORD_WRAP
    });
    var tbxUsername = new kony.ui.TextBox2({
        "autoCapitalize": constants.TEXTBOX_AUTO_CAPITALIZE_NONE,
        "centerX": "50%",
        "focusSkin": "sknTbxLogin",
        "height": "5.20%",
        "id": "tbxUsername",
        "isVisible": true,
        "keyBoardStyle": constants.TEXTBOX_KEY_BOARD_STYLE_DEFAULT,
        "left": "93dp",
        "placeholder": "Username",
        "secureTextEntry": false,
        "skin": "sknTbxLogin",
        "textInputMode": constants.TEXTBOX_INPUT_MODE_ANY,
        "top": "15%",
        "width": "75%"
    }, {
        "containerHeightMode": constants.TEXTBOX_FONT_METRICS_DRIVEN_HEIGHT,
        "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
        "padding": [3, 0, 0, 0],
        "paddingInPixel": false
    }, {
        "autoCorrect": false,
        "closeButtonRequired": true,
        "keyboardActionLabel": constants.TEXTBOX_KEYBOARD_LABEL_DONE,
        "placeholderSkin": "CopyslTextBox02d095da033a44b",
        "showClearButton": true,
        "showCloseButton": true,
        "showProgressIndicator": true,
        "viewType": constants.TEXTBOX_VIEW_TYPE_DEFAULT
    });
    var flxline = new kony.ui.FlexContainer({
        "autogrowMode": kony.flex.AUTOGROW_NONE,
        "centerX": "50%",
        "clipBounds": true,
        "height": "2px",
        "id": "flxline",
        "isVisible": true,
        "layoutType": kony.flex.FREE_FORM,
        "left": "166dp",
        "skin": "CopyslFbox0eb0d8b37147840",
        "top": "2dp",
        "width": "75%",
        "zIndex": 1
    }, {}, {});
    flxline.setDefaultUnit(kony.flex.DP);
    flxline.add();
    var tbxPassword = new kony.ui.TextBox2({
        "autoCapitalize": constants.TEXTBOX_AUTO_CAPITALIZE_NONE,
        "centerX": "50%",
        "focusSkin": "sknTbxLogin",
        "height": "5.20%",
        "id": "tbxPassword",
        "isVisible": true,
        "keyBoardStyle": constants.TEXTBOX_KEY_BOARD_STYLE_DEFAULT,
        "placeholder": "Password",
        "secureTextEntry": true,
        "skin": "sknTbxLogin",
        "textInputMode": constants.TEXTBOX_INPUT_MODE_ANY,
        "top": "3%",
        "width": "75%"
    }, {
        "containerHeightMode": constants.TEXTBOX_FONT_METRICS_DRIVEN_HEIGHT,
        "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
        "padding": [3, 0, 0, 0],
        "paddingInPixel": false
    }, {
        "autoCorrect": false,
        "closeButtonRequired": true,
        "keyboardActionLabel": constants.TEXTBOX_KEYBOARD_LABEL_DONE,
        "placeholderSkin": "CopyslTextBox02d095da033a44b",
        "showClearButton": true,
        "showCloseButton": true,
        "showProgressIndicator": true,
        "viewType": constants.TEXTBOX_VIEW_TYPE_DEFAULT
    });
    var flxline1 = new kony.ui.FlexContainer({
        "autogrowMode": kony.flex.AUTOGROW_NONE,
        "centerX": "50%",
        "clipBounds": true,
        "height": "2px",
        "id": "flxline1",
        "isVisible": true,
        "layoutType": kony.flex.FREE_FORM,
        "left": "166dp",
        "skin": "CopyslFbox0eb0d8b37147840",
        "top": "2dp",
        "width": "75%",
        "zIndex": 1
    }, {}, {});
    flxline1.setDefaultUnit(kony.flex.DP);
    flxline1.add();
    var btnLogin = new kony.ui.Button({
        "centerX": "50%",
        "focusSkin": "CopyslButtonGlossRed047aaf0f1e57140",
        "height": "50dp",
        "id": "btnLogin",
        "isVisible": true,
        "left": "85dp",
        "onClick": AS_Button_43ad23f6973742e88aeb3f43d3c24750,
        "skin": "CopyslButtonGlossBlue022b34bee816b42",
        "text": "Login",
        "top": "7%",
        "width": "260dp",
        "zIndex": 1
    }, {
        "contentAlignment": constants.CONTENT_ALIGN_CENTER,
        "displayText": true,
        "padding": [0, 0, 0, 0],
        "paddingInPixel": false
    }, {
        "showProgressIndicator": true
    });
    flxOuter.add(
    Label0ddb9e0e74d8d42, tbxUsername, flxline, tbxPassword, flxline1, btnLogin);
    frmLogin.add(
    flxOuter);
};

function frmLoginGlobals() {
    frmLogin = new kony.ui.Form2({
        "addWidgets": addWidgetsfrmLogin,
        "enabledForIdleTimeout": false,
        "id": "frmLogin",
        "layoutType": kony.flex.FREE_FORM,
        "needAppMenu": false,
        "skin": "CopyslForm0b02761fac20f49"
    }, {
        "displayOrientation": constants.FORM_DISPLAY_ORIENTATION_PORTRAIT,
        "layoutType": kony.flex.FREE_FORM,
        "padding": [0, 0, 0, 0],
        "paddingInPixel": false
    }, {
        "configureExtendBottom": false,
        "configureExtendTop": false,
        "configureStatusBarStyle": false,
        "footerOverlap": false,
        "formTransparencyDuringPostShow": "100",
        "headerOverlap": false,
        "inputAccessoryViewType": constants.FORM_INPUTACCESSORYVIEW_CANCEL,
        "needsIndicatorDuringPostShow": false,
        "retainScrollPosition": false,
        "titleBar": false,
        "titleBarSkin": "slTitleBar"
    });
};